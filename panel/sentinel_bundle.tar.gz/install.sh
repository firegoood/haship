#!/usr/bin/env bash
# ==============================================================================
# Sentinel Installer — VLESS Health Monitor & Management Panel
# GitHub: https://github.com/pdnczone/sentinel
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

INSTALL_DIR="/opt/sentinel"
SERVICE_NAME="sentinel"
REPO="pdnczone/sentinel"
BRANCH="main"

MIRRORS=(
    ""
    "https://ghproxy.net/"
    "https://mirror.ghproxy.com/"
    "https://gh-proxy.com/"
)

check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "${RED}[ERROR] Please run as root (sudo bash ...)${NC}" >&2
        exit 1
    fi
}

download_with_fallback() {
    local target_url="$1"
    local output_file="$2"
    local downloaded=0

    for prefix in "${MIRRORS[@]}"; do
        local full_url="${prefix}${target_url}"
        echo -e "${CYAN}--> Trying: ${full_url}${NC}"
        if curl -fsSL --connect-timeout 8 --max-time 90 "$full_url" -o "$output_file"; then
            if [ -s "$output_file" ]; then
                downloaded=1
                break
            fi
        fi
        echo -e "${YELLOW}--> Failed, trying next mirror...${NC}"
    done

    if [ $downloaded -ne 1 ]; then
        echo -e "${RED}[ERROR] Failed to download from all mirrors: ${target_url}${NC}" >&2
        return 1
    fi
    return 0
}

install_dependencies() {
    echo -e "${BLUE}[1/5] Installing dependencies...${NC}"
    if command -v apt-get >/dev/null 2>&1; then
        apt-get update -y -qq
        apt-get install -y -qq curl python3 unzip procps tar >/dev/null 2>&1
    elif command -v dnf >/dev/null 2>&1; then
        dnf install -y -q curl python3 unzip procps-ng tar >/dev/null 2>&1
    elif command -v yum >/dev/null 2>&1; then
        yum install -y -q curl python3 unzip procps-ng tar >/dev/null 2>&1
    elif command -v pacman >/dev/null 2>&1; then
        pacman -Sy --noconfirm curl python unzip procps-ng tar >/dev/null 2>&1
    elif command -v apk >/dev/null 2>&1; then
        apk add --no-cache curl python3 unzip procps tar >/dev/null 2>&1
    fi
}

detect_arch() {
    local arch
    arch=$(uname -m)
    case "$arch" in
        x86_64|amd64)
            echo "64"
            ;;
        aarch64|arm64)
            echo "arm64-v8a"
            ;;
        armv7*|armhf)
            echo "arm32-v7a"
            ;;
        *)
            echo -e "${RED}[ERROR] Unsupported architecture: ${arch}${NC}" >&2
            exit 1
            ;;
    esac
}

download_sentinel() {
    mkdir -p "$INSTALL_DIR"

    # Stop service if running
    if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
        systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    fi

    if [ -f "${INSTALL_DIR}/app.py" ] && [ -f "${INSTALL_DIR}/index.html" ]; then
        echo -e "${GREEN}[2/5] Sentinel files already present in ${INSTALL_DIR}.${NC}"
        chmod +x "${INSTALL_DIR}/app.py" "${INSTALL_DIR}/install.sh" 2>/dev/null || true
        return 0
    fi

    echo -e "${BLUE}[2/5] Downloading Sentinel files into ${INSTALL_DIR}...${NC}"

    local tmp_tar="/tmp/sentinel-main.tar.gz"
    local archive_url="https://github.com/${REPO}/archive/refs/heads/${BRANCH}.tar.gz"

    download_with_fallback "$archive_url" "$tmp_tar"

    # Extract while preserving database and credentials if they exist
    tar -xzf "$tmp_tar" --strip-components=1 -C "$INSTALL_DIR"
    rm -f "$tmp_tar"
    chmod +x "${INSTALL_DIR}/app.py" "${INSTALL_DIR}/install.sh" 2>/dev/null || true
}

download_xray() {
    local xray_bin="${INSTALL_DIR}/xray"
    if [ -x "$xray_bin" ]; then
        echo -e "${GREEN}[3/5] Xray binary already present in ${xray_bin}.${NC}"
        return 0
    fi

    echo -e "${BLUE}[3/5] Downloading Xray core binary...${NC}"
    local arch
    arch=$(detect_arch)
    local tmp_zip="/tmp/xray.zip"
    local xray_url="https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-${arch}.zip"

    download_with_fallback "$xray_url" "$tmp_zip"

    unzip -o -q "$tmp_zip" xray -d "$INSTALL_DIR"
    rm -f "$tmp_zip"
    chmod +x "$xray_bin"
}

setup_systemd() {
    echo -e "${BLUE}[4/5] Setting up systemd service (${SERVICE_NAME})...${NC}"
    local service_path="/etc/systemd/system/${SERVICE_NAME}.service"

    cat <<EOF > "$service_path"
[Unit]
Description=Sentinel VLESS Health Monitor & Web Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/python3 ${INSTALL_DIR}/app.py
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable "$SERVICE_NAME" >/dev/null 2>&1
    systemctl restart "$SERVICE_NAME"
}

get_public_ip() {
    local ip
    for p in "https://api.ipify.org" "https://icanhazip.com" "https://ifconfig.me"; do
        ip=$(curl -fsSL --connect-timeout 2 --max-time 4 "$p" 2>/dev/null | tr -d '[:space:]')
        if [[ "$ip" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
            echo "$ip"
            return 0
        fi
    done
    hostname -I 2>/dev/null | awk '{print $1}' || echo "SERVER_IP"
}

show_info() {
    echo -e "${BLUE}[5/5] Checking service and retrieving credentials...${NC}"
    local cred_file="${INSTALL_DIR}/credentials.txt"
    local counter=0

    while [ ! -f "$cred_file" ] && [ $counter -lt 15 ]; do
        sleep 1
        counter=$((counter + 1))
    done

    if [ ! -f "$cred_file" ]; then
        echo -e "${YELLOW}[WARNING] Credentials file not generated yet. Check: systemctl status ${SERVICE_NAME}${NC}"
        return 0
    fi

    local path_val port_val pass_val
    path_val=$(grep '^path=' "$cred_file" | cut -d'=' -f2)
    port_val=$(grep '^port=' "$cred_file" | cut -d'=' -f2)
    pass_val=$(grep '^password=' "$cred_file" | cut -d'=' -f2)
    local ip_val
    ip_val=$(get_public_ip)

    echo ""
    echo -e "${GREEN}================================================================${NC}"
    echo -e "${BOLD}${GREEN}        🚀 Sentinel نصب و با موفقیت راه‌اندازی شد!        ${NC}"
    echo -e "${GREEN}================================================================${NC}"
    echo -e "  ${BOLD}🌐 آدرس پنل (Panel URL):${NC}    ${CYAN}http://${ip_val}:${port_val}${path_val}${NC}"
    echo -e "  ${BOLD}🔑 رمز عبور (Password):${NC}     ${YELLOW}${pass_val}${NC}"
    echo -e "  ${BOLD}📁 مسیر نصب (Directory):${NC}    ${INSTALL_DIR}"
    echo -e "  ${BOLD}📄 فایل اطلاعات ورود:${NC}       cat ${cred_file}"
    echo -e "${GREEN}----------------------------------------------------------------${NC}"
    echo -e "  ${BOLD}دستورات مدیریت سرویس:${NC}"
    echo -e "  • وضعیت:    ${CYAN}systemctl status ${SERVICE_NAME}${NC}"
    echo -e "  • ری‌استارت:  ${CYAN}systemctl restart ${SERVICE_NAME}${NC}"
    echo -e "  • لاگ زنده:  ${CYAN}journalctl -u ${SERVICE_NAME} -f${NC}"
    echo -e "  • حذف کامل:  ${CYAN}bash ${INSTALL_DIR}/install.sh --uninstall${NC}"
    echo -e "${GREEN}================================================================${NC}"
    echo ""
}

uninstall_sentinel() {
    check_root
    echo -e "${YELLOW}Uninstalling Sentinel...${NC}"
    systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    systemctl disable "$SERVICE_NAME" 2>/dev/null || true
    rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
    systemctl daemon-reload
    rm -rf "$INSTALL_DIR"
    echo -e "${GREEN}Sentinel completely removed.${NC}"
    exit 0
}

# --- Main CLI Router ---
if [ "$1" = "--uninstall" ] || [ "$1" = "uninstall" ]; then
    uninstall_sentinel
fi

check_root
install_dependencies
download_sentinel
download_xray
setup_systemd
show_info
