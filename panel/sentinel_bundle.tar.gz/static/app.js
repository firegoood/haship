/* Sentinel front-end. Vanilla ES2022, no dependencies. */
'use strict';
const P = location.pathname.replace(/\/$/, '');
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { data: null, range: '24h', view: localStorage.getItem('sentinel_view') || 'cards', tab: 'dashboard', drawerId: null, sparks: {}, polling: null, paused: false };

/* ---------- toast ---------- */
let toastT;
function toast(msg, kind = 'ok') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast';
  el.style.border = kind === 'err' ? '1px solid var(--er)' : '1px solid var(--ln2)';
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.add('hidden'), 3500);
}

/* ---------- api ---------- */
async function api(path, body) {
  const r = await fetch(`${P}/api/${path}`, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { 'X-R': '1', 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (r.status === 401 && path !== 'login') { showLogin(); throw new Error('unauthorized'); }
  return r;
}
const getJSON = async p => (await api(p)).json();

/* ---------- format helpers ---------- */
const ago = ts => {
  if (!ts) return '—';
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)}m ago` : s < 86400 ? `${Math.round(s / 3600)}h ago` : `${Math.round(s / 86400)}d ago`;
};
const dur = s => s < 60 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${Math.floor(s / 3600)}h ${Math.floor(s % 3600 / 60)}m`;
const when = ts => ts ? new Date(ts * 1000).toLocaleString() : '—';
const latColor = ms => ms == null ? 'var(--mu)' : ms < 250 ? 'var(--ok)' : ms < 600 ? 'var(--wr)' : 'var(--er)';
const state = c => c.enabled === 0 ? 'paused' : (c.is_down && c.ok_iran === 1) ? 'iran_only' : c.is_down ? 'down' : c.last_ok === 1 ? 'up' : c.last_ok === 0 ? 'fail' : 'new';
const badge = c => ({
  paused: '<span class="badge dim"><span class="dot"></span>PAUSED</span>',
  iran_only: '<span class="badge warn" title="International blocked, Iran intranet connected"><span class="dot"></span>IRAN ONLY</span>',
  down: '<span class="badge err"><span class="dot"></span>DOWN</span>',
  up: '<span class="badge ok"><span class="dot"></span>ONLINE</span>',
  fail: '<span class="badge warn"><span class="dot"></span>FAILING</span>',
  new: '<span class="badge dim"><span class="dot"></span>QUEUED</span>',
}[state(c)]);
const _px = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
function rgba(css, a) { _px.clearRect(0, 0, 1, 1); _px.fillStyle = '#38bdf8'; _px.fillStyle = css; _px.fillRect(0, 0, 1, 1); const [r, g, b] = _px.getImageData(0, 0, 1, 1).data; return `rgba(${r},${g},${b},${a})`; }
const speedPill = c => c.last_speed_mbps
  ? `<span class="pill pill-speed" title="100MB tested ${ago(c.last_speed_time)}">⚡ ${c.last_speed_mbps} Mbps</span>`
  : '';
const subBadge = c => c.sub_name
  ? `<span class="pill pill-sub" title="${esc(c.sub_url || '')}">Feed: ${esc(c.sub_name)}</span>`
  : `<span class="pill pill-port">Manual</span>`;
const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--ac').trim() || '#38bdf8';

/* ---------- auth / shell ---------- */
function showLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); stopPolling(); }
function showApp() { $('#login').classList.add('hidden'); $('#app').classList.remove('hidden'); startPolling(); }

$('#toggle').addEventListener('click', () => {
  const i = $('#p'), show = i.type === 'password';
  i.type = show ? 'text' : 'password';
  $('#eye').innerHTML = '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>' + (show ? '<path d="M3 3l18 18"/>' : '');
});
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#loginBtn'); btn.disabled = true;
  const totpCode = ($('#totpCode')?.value || '').trim();
  try {
    const r = await api('login', { password: $('#p').value, totp_code: totpCode });
    const d = await r.json().catch(() => ({}));
    if (r.ok) {
      $('#p').value = ''; if ($('#totpCode')) $('#totpCode').value = '';
      $('#codeField')?.classList.add('hidden');
      $('#loginErr').textContent = '';
      showApp(); await refresh();
    } else {
      if (d.need_2fa) {
        $('#codeField').classList.remove('hidden');
        $('#totpCode').focus();
        $('#loginErr').textContent = totpCode ? 'Invalid 6-digit code.' : 'Enter 6-digit 2FA code from authenticator app.';
      } else {
        $('#loginErr').textContent = r.status === 429 ? 'Too many attempts. Wait 5 minutes.' : (d.error || 'Invalid password.');
      }
    }
  } catch { $('#loginErr').textContent = 'Network or server error.'; }
  btn.disabled = false;
});
$('#logoutBtn').addEventListener('click', async () => { await api('logout', {}); showLogin(); });

/* ---------- tabs ---------- */
const TITLES = { dashboard: ['Dashboard', 'Live Edge Health · Real-time Probes'], configs: ['Configs', 'Every node Sentinel probes'], speedtest: ['Speed Test', '100MB CDN benchmark & node throughput ranking'], incidents: ['Incidents', 'Outage & recovery history'], settings: ['Settings', 'Probe engine, Telegram and appearance'] };
function switchTab(name) {
  S.tab = name;
  $$('#sideNav .nav-item').forEach(b => { b.classList.toggle('on', b.dataset.tab === name); b.setAttribute('aria-selected', b.dataset.tab === name); });
  $$('main.page > section').forEach(s => s.classList.toggle('hidden', s.id !== `tab-${name}`));
  [$('#topTitle').textContent, $('#subRole').textContent] = TITLES[name];
  history.replaceState(null, '', `#${name}`);
  if (name === 'incidents') loadIncidents();
  if (name === 'dashboard') requestAnimationFrame(drawHistory);
  if (name === 'speedtest') renderSpeedTestTab();
  if (name === 'settings') load2FaStatus();
}
$$('#sideNav .nav-item').forEach(b => b.addEventListener('click', () => switchTab(b.dataset.tab)));

/* ---------- polling ---------- */
function startPolling() { stopPolling(); S.polling = setInterval(() => { if (!document.hidden) refresh(); }, 3000); }
function stopPolling() { clearInterval(S.polling); S.polling = null; }
async function refresh() {
  try {
    S.data = await getJSON('dashboard');
    S.sparks = await getJSON('sparks').catch(() => S.sparks);
    if (!S._st || Date.now() - S._st > 30000) { S._st = Date.now(); loadSubs(); loadCleanSub(); }
    render();
    if (S.drawerId) loadDrawer(S.drawerId, true);
    if (S.tab === 'speedtest') renderSpeedTestTab();
  } catch { /* 401 handled in api() */ }
}

/* ---------- render ---------- */
function render() {
  const d = S.data; if (!d) return;
  const cfgs = d.configs || [];
  const up = cfgs.filter(c => state(c) === 'up').length;
  const down = cfgs.filter(c => state(c) === 'down').length;
  const lats = cfgs.filter(c => state(c) === 'up' && c.latency).map(c => c.latency);
  const avg = lats.length ? Math.round(lats.reduce((a, b) => a + b, 0) / lats.length) : null;

  $('#kpiTotal').textContent = cfgs.length;
  $('#kpiTotalSub').textContent = `${cfgs.filter(c => c.enabled !== 0).length} enabled`;
  const u = $('#kpiUp'); u.textContent = up; u.style.color = up ? 'var(--ok)' : 'var(--tx)';
  const dn = $('#kpiDown'); dn.textContent = down; dn.style.color = down ? 'var(--er)' : 'var(--tx)';
  $('#kpiPing').textContent = avg ? `${avg}ms` : '—';
  const nb = $('#cfgBadge'); nb.textContent = cfgs.length; nb.className = `badge sm nav-badge ${down ? 'err' : up ? 'ok' : 'dim'}`;
  const tg = $('#kpiTg'); tg.textContent = d.settings.token_configured && d.settings.chat ? 'Connected' : 'Not set';
  $('#kpiTgSub').textContent = d.pending_alerts ? `${d.pending_alerts} alert(s) queued` : 'No queued alerts';

  renderDashTable(cfgs);
  updateSubFilterOptions(cfgs);
  renderConfigs(cfgs);
  if (!$('#tab-settings').dataset.filled) { fillSettings(d.settings); $('#tab-settings').dataset.filled = '1'; }
  $$('.acc-btn').forEach(b => b.classList.toggle('selected', b.dataset.acc === document.documentElement.dataset.acc));
}

function spark(id, w = 100, h = 26) {
  const v = S.sparks[id];
  if (!v || v.length < 2) return '';
  const nums = v.filter(x => x != null), mx = Math.max(...nums, 1), step = w / (v.length - 1);
  let d = '', pen = false;
  v.forEach((x, i) => { if (x == null) { pen = false; return; } d += `${pen ? 'L' : 'M'}${(i * step).toFixed(1)},${(h - 2 - (x / mx) * (h - 4)).toFixed(1)} `; pen = true; });
  const fails = v.map((x, i) => x == null ? `<circle cx="${(i * step).toFixed(1)}" cy="${h - 2}" r="1.6" fill="var(--er)"/>` : '').join('');
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="${accent()}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>${fails}</svg>`;
}

function renderSlaBars(bars) {
  if (!bars || !bars.length) return '';
  return `<div class="sla-bar-wrap" title="24h SLA Health History">` + bars.map(b => {
    let cls = 'none';
    let tip = `${b.h}: No checks`;
    if (b.status === 1) {
      cls = 'up';
      tip = `${b.h}: 100% UP${b.ms ? ` (${b.ms}ms)` : ''}`;
    } else if (b.status === 0) {
      cls = 'down';
      tip = `${b.h}: 100% Outage`;
    } else if (b.status === 2) {
      cls = 'degraded';
      tip = `${b.h}: Degraded (${b.up_pct}% UP${b.ms ? `, ${b.ms}ms` : ''})`;
    }
    return `<div class="sla-bar ${cls}" title="${esc(tip)}"></div>`;
  }).join('') + `</div>`;
}

function renderDashTable(cfgs) {
  $('#dashTable').innerHTML = cfgs.length ? cfgs.map(c => `
    <tr data-open="${c.id}" style="cursor:pointer">
      <td>${c.country_flag ? `<span class="cfg-flag" title="${esc(c.country_name || c.country_code)}">${c.country_flag}</span> ` : ''}<strong>${esc(c.name)}</strong></td>
      <td class="cfg-addr">${esc(c.addr)}</td>
      <td>${subBadge(c)}</td>
      <td>${badge(c)}</td>
      <td class="mono" style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</td>
      <td>${c.uptime != null ? c.uptime + '%' : '—'}</td>
      <td><div style="display:flex;flex-direction:column;gap:3px;min-width:130px"><div class="cfg-spark-wrap">${spark(c.id)}</div>${renderSlaBars(c.sla_bars)}</div></td>
      <td style="color:var(--mu);font-size:12px">${ago(c.last_check)}</td>
    </tr>`).join('')
    : '<tr><td colspan="8" class="u-mu" style="text-align:center;padding:28px">No configs yet. Open <b>Configs</b> and import some.</td></tr>';
}

function updateSubFilterOptions(cfgs) {
  const sel = $('#cfgSubFilter'); if (!sel) return;
  const curVal = sel.value;
  const groups = {};
  let manualCount = 0;
  for (const c of cfgs) {
    if (c.sub_id) {
      if (!groups[c.sub_id]) groups[c.sub_id] = { name: c.sub_name || c.sub_id, count: 0 };
      groups[c.sub_id].count++;
    } else {
      manualCount++;
    }
  }
  let opts = `<option value="">All Sources (${cfgs.length})</option>`;
  for (const [sid, g] of Object.entries(groups)) {
    opts += `<option value="${esc(sid)}">${esc(g.name)} (${g.count})</option>`;
  }
  if (manualCount > 0) {
    opts += `<option value="__manual__">Manual (${manualCount})</option>`;
  }
  sel.innerHTML = opts;
  if (curVal && (curVal === '__manual__' || groups[curVal])) sel.value = curVal;
}

function renderConfigs(cfgs) {
  const q = ($('#cfgSearch').value || '').toLowerCase();
  const subSel = $('#cfgSubFilter')?.value || '';
  const list = cfgs.filter(c => {
    if (subSel === '__manual__' && c.sub_id) return false;
    if (subSel && subSel !== '__manual__' && c.sub_id !== subSel) return false;
    if (q && !c.name.toLowerCase().includes(q) && !c.addr.toLowerCase().includes(q)) return false;
    return true;
  });
  $$('.view-seg button').forEach(b => b.classList.toggle('on', b.dataset.v === S.view));
  $('#cfgGrid').classList.toggle('hidden', S.view !== 'cards');
  $('#cfgTableWrap').classList.toggle('hidden', S.view !== 'table');
  if (!list.length) {
    const msg = `<div style="grid-column:1/-1;text-align:center;padding:48px 16px;color:var(--mu)">${cfgs.length ? 'No match.' : 'No configs registered yet. Click <b>Import VLESS</b> to start.'}</div>`;
    $('#cfgGrid').innerHTML = msg; $('#cfgTable').innerHTML = `<tr><td colspan="7" class="u-mu" style="text-align:center;padding:24px">${cfgs.length ? 'No match.' : 'No configs.'}</td></tr>`;
    return;
  }
  $('#cfgGrid').innerHTML = list.map(c => `
    <div class="cfg-card" data-open="${c.id}" style="${c.enabled === 0 ? 'opacity:.6' : ''}">
      <div class="cfg-head"><div><div class="cfg-title">${c.country_flag ? `<span class="cfg-flag" title="${esc(c.country_name || c.country_code)}">${c.country_flag}</span> ` : ''}${esc(c.name)}</div><div class="cfg-addr">${esc(c.addr)}</div></div>${badge(c)}</div>
      <div class="cfg-pills"><span class="pill pill-proto">${esc((c.protocol || 'vless').toUpperCase())}</span><span class="pill pill-net">${esc(c.network || 'tcp')}</span><span class="pill pill-sec">${esc(c.security || 'none')}</span>${subBadge(c)}${speedPill(c)}</div>
      <div class="cfg-spark-wrap" style="width:100%;height:32px">${spark(c.id, 300, 32)}</div>
      ${renderSlaBars(c.sla_bars)}
      ${state(c) === 'down' || state(c) === 'fail' ? `<div style="font-size:11px;color:var(--er);background:rgba(239,68,68,.08);padding:6px 8px;border-radius:6px;word-break:break-all">${esc(c.last_error)}</div>` : ''}
      <div class="cfg-meta"><span>Ping <b style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</b></span><span>Uptime <b style="color:var(--tx)">${c.uptime != null ? c.uptime + '%' : '—'}</b></span><span>${ago(c.last_check)}</span></div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding-top:4px;border-top:1px dashed var(--ln)">
        <button class="hashem-btn hashem-btn-secondary sm" data-sp-test="${c.id}" onclick="event.stopPropagation()">⚡ SP-Test 100MB</button>
        <span style="font-size:11px;color:var(--dim)">${c.last_speed_mbps ? c.last_speed_mbps + ' Mbps' : 'Not tested'}</span>
      </div>
    </div>`).join('');
  $('#cfgTable').innerHTML = list.map(c => `
    <tr data-open="${c.id}" style="cursor:pointer;${c.enabled === 0 ? 'opacity:.6' : ''}">
      <td>${c.country_flag ? `<span class="cfg-flag" title="${esc(c.country_name || c.country_code)}">${c.country_flag}</span> ` : ''}<strong>${esc(c.name)}</strong></td><td class="cfg-addr">${esc(c.addr)}</td>
      <td>${subBadge(c)}</td>
      <td><span class="pill pill-proto">${esc((c.protocol || 'vless').toUpperCase())}</span> <span class="pill pill-net">${esc(c.network || 'tcp')}</span> <span class="pill pill-sec">${esc(c.security || 'none')}</span></td>
      <td>${badge(c)}</td><td class="mono" style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</td>
      <td>${c.uptime != null ? c.uptime + '%' : '—'}</td><td style="color:var(--mu);font-size:12px">${ago(c.last_check)}</td>
    </tr>`).join('');
}
document.addEventListener('click', e => { const t = e.target.closest('[data-open]'); if (t) openDrawer(t.dataset.open); });
$('#cfgSearch').addEventListener('input', () => renderConfigs(S.data?.configs || []));
$('#cfgSubFilter')?.addEventListener('change', () => renderConfigs(S.data?.configs || []));
$$('.view-seg button').forEach(b => b.addEventListener('click', () => { S.view = b.dataset.v; localStorage.setItem('sentinel_view', S.view); renderConfigs(S.data?.configs || []); }));

/* ---------- speed test tab ---------- */
function renderSpeedTestTab() {
  const cfgs = S.data?.configs || [];
  if (!cfgs.length) return;

  // Populate Hero Select
  const sel = $('#spSelect');
  if (sel) {
    const curId = sel.value;
    sel.innerHTML = cfgs.map(c => `<option value="${c.id}">${esc(c.name)} (${esc(c.addr)})</option>`).join('');
    if (curId && cfgs.find(c => c.id === curId)) sel.value = curId;
    updateHeroMeta();
  }

  // Sort Leaderboard: fastest first, untested at bottom
  const sorted = [...cfgs].sort((a, b) => (b.last_speed_mbps || 0) - (a.last_speed_mbps || 0));
  const maxSpeed = Math.max(100, ...sorted.map(c => c.last_speed_mbps || 0));

  const el = $('#spGrid');
  if (!el) return;
  el.innerHTML = sorted.map((c, i) => {
    const rankClass = i === 0 && c.last_speed_mbps ? 'rank-1' : i === 1 && c.last_speed_mbps ? 'rank-2' : i === 2 && c.last_speed_mbps ? 'rank-3' : 'rank-other';
    const rankLabel = c.last_speed_mbps ? `#${i + 1}` : '—';
    const pct = c.last_speed_mbps ? Math.min(100, (c.last_speed_mbps / maxSpeed) * 100).toFixed(1) : 0;
    return `
      <div class="cfg-card">
        <div class="cfg-head">
          <div>
            <div class="cfg-title" style="display:flex;align-items:center;gap:6px">
              <span class="rank-badge ${rankClass}">${rankLabel}</span>
              ${esc(c.name)}
            </div>
            <div class="cfg-addr">${esc(c.addr)}</div>
          </div>
          ${badge(c)}
        </div>
        <div class="cfg-pills">
          <span class="pill pill-proto">VLESS</span>
          <span class="pill pill-net">${esc(c.network || 'tcp')}</span>
          ${subBadge(c)}
        </div>
        <div style="background:var(--s2);border:1px solid var(--ln);border-radius:var(--r-md);padding:10px 12px;margin-top:2px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:11px;color:var(--mu);text-transform:uppercase;font-weight:700">100MB Speed</span>
            <span style="font-size:16px;font-weight:800;color:${c.last_speed_mbps ? 'var(--ac)' : 'var(--mu)'};font-family:var(--font-mono)">
              ${c.last_speed_mbps ? `⚡ ${c.last_speed_mbps} Mbps` : 'Not tested'}
            </span>
          </div>
          <div class="sp-bar-wrap">
            <div class="sp-bar-fill" style="width:${pct}%"></div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:var(--dim);margin-top:4px">
            <span>Ping: <b style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</b></span>
            <span>${c.last_speed_time ? ago(c.last_speed_time) : 'No tests run'}</span>
          </div>
        </div>
        <button class="hashem-btn hashem-btn-primary sp-card-btn" data-sp-test="${c.id}">
          ⚡ Test Speed (100MB)
        </button>
      </div>`;
  }).join('');
}

function updateHeroMeta() {
  const sel = $('#spSelect'); if (!sel) return;
  const c = S.data?.configs.find(x => x.id === sel.value);
  if (!c) return;
  $('#spHeroPing').textContent = c.latency ? `${c.latency}ms` : '—';
  $('#spHeroPort').textContent = `:${c.port}`;
  $('#spHeroSource').textContent = c.sub_name ? `Feed: ${c.sub_name}` : 'Manual';
  $('#spHeroSpeed').textContent = c.last_speed_mbps ? `⚡ ${c.last_speed_mbps} Mbps` : '0.0 Mbps';
  $('#spHeroStatus').textContent = c.last_speed_time ? `Last tested ${ago(c.last_speed_time)}` : 'Ready to test';
}

$('#spSelect')?.addEventListener('change', updateHeroMeta);

$('#spHeroTestBtn')?.addEventListener('click', async () => {
  const sel = $('#spSelect'); if (!sel || !sel.value) return;
  const id = sel.value;
  const btn = $('#spHeroTestBtn'); btn.disabled = true; btn.textContent = '⚡ Downloading 100MB...';
  $('#spHeroStatus').textContent = 'Downloading 100MB test chunk from Cloudflare CDN...';
  try {
    const res = await (await api('speedtest', { id })).json();
    if (res.ok) {
      toast(`Speed: ${res.mbps} Mbps (${res.elapsed}s)`);
      $('#spHeroSpeed').textContent = `⚡ ${res.mbps} Mbps`;
      $('#spHeroStatus').textContent = `Downloaded 100MB in ${res.elapsed}s`;
      await refresh();
      renderSpeedTestTab();
    } else {
      toast(res.error || 'Speed test failed', 'err');
      $('#spHeroStatus').textContent = `Failed: ${res.error || 'Error'}`;
    }
  } catch(e) {
    toast('Communication error', 'err');
  } finally {
    btn.disabled = false; btn.textContent = 'Test Selected Config';
  }
});

$('#spAllBtn')?.addEventListener('click', () => $('#spTestAllBtn')?.click());

/* ---------- charts ---------- */
function lineChart(canvas, pts, span, opts = {}) {
  const dpr = devicePixelRatio || 1, r = canvas.getBoundingClientRect();
  if (!r.width) return;
  canvas.width = r.width * dpr; canvas.height = r.height * dpr;
  const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const W = r.width, H = r.height, L = 44, B = 22, T = 10, R = 8, light = document.documentElement.dataset.t === 'light';
  ctx.clearRect(0, 0, W, H);
  const good = pts.filter(p => p.ok && p.latency_ms);
  const top = Math.ceil(Math.max(300, ...good.map(p => p.latency_ms)) / 100) * 100;
  ctx.font = '10px ui-monospace,monospace'; ctx.textAlign = 'right'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = T + (H - T - B) * i / 4;
    ctx.strokeStyle = light ? 'rgba(0,0,0,.07)' : 'rgba(255,255,255,.06)'; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke();
    ctx.fillStyle = light ? '#52525b' : '#71717a'; ctx.fillText(`${Math.round(top * (1 - i / 4))}ms`, L - 6, y + 3);
  }
  if (!pts.length) { ctx.fillStyle = '#71717a'; ctx.textAlign = 'center'; ctx.font = '12px system-ui'; ctx.fillText('Collecting probe history…', W / 2, H / 2); return; }
  const NB = opts.buckets || 40, start = Date.now() / 1000 - span, bw = span / NB;
  const bk = Array.from({ length: NB }, () => ({ l: [], n: 0, f: 0 }));
  for (const p of pts) { const b = bk[Math.min(NB - 1, Math.max(0, Math.floor((p.checked_at - start) / bw)))]; b.n++; if (p.ok && p.latency_ms) b.l.push(p.latency_ms); else if (!p.ok) b.f++; }
  const X = i => L + i * (W - L - R) / (NB - 1), Y = v => T + (H - T - B) * (1 - v / top);
  bk.forEach((b, i) => { if (b.f && b.f === b.n) { ctx.fillStyle = 'rgba(239,68,68,.16)'; ctx.fillRect(X(i) - (W - L - R) / NB / 2, T, (W - L - R) / NB, H - T - B); } });
  let xy = bk.map((b, i) => b.l.length ? [X(i), Y(b.l.reduce((a, c) => a + c, 0) / b.l.length)] : null).filter(Boolean);
  if (!xy.length) { ctx.fillStyle = '#71717a'; ctx.textAlign = 'center'; ctx.font = '12px system-ui'; ctx.fillText('No successful probes in this range.', W / 2, H / 2); return; }
  if (xy.length === 1) { xy = [[L, xy[0][1]], [W - R, xy[0][1]]]; }
  const ac = accent(), g = ctx.createLinearGradient(0, T, 0, H - B);
  g.addColorStop(0, rgba(ac, .25)); g.addColorStop(1, rgba(ac, 0));
  ctx.beginPath(); xy.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.strokeStyle = ac; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
  ctx.lineTo(xy.at(-1)[0], H - B); ctx.lineTo(xy[0][0], H - B); ctx.closePath(); ctx.fillStyle = g; ctx.fill();
}
async function drawHistory() {
  const c = $('#histChart'); if (!c || S.tab !== 'dashboard') return;
  const d = await getJSON(`history?range=${S.range}`).catch(() => null);
  if (d) lineChart(c, d.points, d.span);
}
$$('#chartFilters button').forEach(b => b.addEventListener('click', () => {
  $$('#chartFilters button').forEach(x => x.removeAttribute('aria-pressed')); b.setAttribute('aria-pressed', 'true');
  S.range = b.dataset.r; drawHistory();
}));
setInterval(() => { if (!document.hidden && S.tab === 'dashboard') drawHistory(); }, 15000);
addEventListener('resize', () => { if (S.tab === 'dashboard') drawHistory(); });

/* ---------- detail drawer ---------- */
function openDrawer(id) { S.drawerId = id; $('#detOv').classList.add('open'); $('#detDrawer').classList.add('open'); $('#detBody').innerHTML = '<div class="u-mu">Loading…</div>'; loadDrawer(id); }
function closeDrawer() { S.drawerId = null; $('#detOv').classList.remove('open'); $('#detDrawer').classList.remove('open'); }
$('#detOv').addEventListener('click', closeDrawer);
$('#detClose').addEventListener('click', closeDrawer);
async function loadDrawer(id, quiet) {
  const d = await getJSON(`config?id=${id}&range=${S.range}`).catch(() => null);
  if (!d || d.error) { if (!quiet) { closeDrawer(); toast('Config not found', 'err'); } return; }
  if (S.drawerId !== id) return;
  const c = d.config, live = S.data?.configs.find(x => x.id === id) || c, st = d.stats;
  const keepName = quiet && document.activeElement?.id === 'detName';
  $('#detTitle').textContent = c.name;
  $('#detBody').innerHTML = `
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">${badge(live)}<span class="pill pill-proto">VLESS</span><span class="pill pill-net">${esc(c.network)}</span><span class="pill pill-sec">${esc(c.security)}</span><span class="pill pill-port">:${c.port}</span></div>
    <div class="det-stat-grid">
      <div class="det-box"><div class="det-box-label">Uptime (${S.range})</div><div class="det-box-val" style="color:${st.uptime == null ? 'var(--tx)' : st.uptime >= 99 ? 'var(--ok)' : st.uptime >= 90 ? 'var(--wr)' : 'var(--er)'}">${st.uptime ?? '—'}${st.uptime != null ? '%' : ''}</div></div>
      <div class="det-box"><div class="det-box-label">Avg latency</div><div class="det-box-val">${st.avg != null ? st.avg + 'ms' : '—'}</div></div>
      <div class="det-box"><div class="det-box-label">Speed (100MB)</div><div class="det-box-val" style="color:var(--ac);font-size:18px">${live.last_speed_mbps ? live.last_speed_mbps + ' Mbps' : '—'}</div></div>
      <div class="det-box"><div class="det-box-label">Probes</div><div class="det-box-val">${st.checks}</div></div>
    </div>
    <div class="det-chart-box"><canvas id="detChart" style="width:100%;height:100%"></canvas></div>
    ${live.last_error && (state(live) === 'down' || state(live) === 'fail') ? `<div style="font-size:12px;color:var(--er);background:rgba(239,68,68,.08);padding:8px 10px;border-radius:8px;word-break:break-all;font-family:var(--font-mono)">${esc(live.last_error)}</div>` : ''}
    <div class="field"><label class="field-lbl">Name</label><div style="display:flex;gap:8px"><input class="hashem-input" id="detName" value="${esc(c.name)}" maxlength="80"><button class="hashem-btn hashem-btn-secondary" id="detRename">Save</button></div></div>
    <div class="field"><label class="field-lbl">Address</label><div class="cfg-addr" style="padding:4px 0">${esc(c.addr)}</div></div>
    <div class="field"><label class="field-lbl">Subscription Source</label><div style="font-size:12px;padding:4px 0">${c.sub_name ? `<span class="pill pill-sub">Feed: ${esc(c.sub_name)}</span> <div class="sub-url" style="margin-top:4px">${esc(c.sub_url || '')}</div>` : '<span class="pill pill-port">Manual Entry</span>'}</div></div>
    <div><div class="field-lbl" style="margin-bottom:6px">Recent incidents</div>${d.incidents.length ? d.incidents.slice(0, 6).map(i => `<div class="det-box" style="margin-bottom:6px;font-size:12px"><b>${when(i.started_at)}</b> &rarr; ${i.resolved_at ? `${when(i.resolved_at)} <span class="u-mu">(${dur(i.resolved_at - i.started_at)})</span>` : '<span class="badge err">ONGOING</span>'}</div>`).join('') : '<div class="u-mu" style="font-size:12px">None.</div>'}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:auto">
      <button class="hashem-btn hashem-btn-primary" id="detSpTest">⚡ Run 100MB SP-Test</button>
      <button class="hashem-btn hashem-btn-secondary" id="detToggle">${c.enabled ? 'Pause' : 'Resume'}</button>
      <button class="hashem-btn hashem-btn-secondary" id="detCopy">Copy URI</button>
      <button class="hashem-btn hashem-btn-danger" id="detDel">Delete</button>
    </div>`;
  if (keepName) $('#detName').focus();
  lineChart($('#detChart'), d.points, d.span, { buckets: 30 });
  $('#detSpTest').onclick = async (e) => {
    const b = e.currentTarget; b.disabled = true; b.textContent = '⚡ Downloading 100MB...';
    try {
      const res = await (await api('speedtest', { id })).json();
      if (res.ok) { toast(`Speed: ${res.mbps} Mbps (${res.elapsed}s)`); refresh(); loadDrawer(id, true); }
      else toast(res.error || 'Speed test failed', 'err');
    } catch { toast('Speed test error', 'err'); }
    finally { b.disabled = false; b.textContent = '⚡ Run 100MB SP-Test'; }
  };
  $('#detRename').onclick = async () => { const r = await api('configs/rename', { id, name: $('#detName').value }); r.ok ? (toast('Renamed'), refresh()) : toast('Rename failed', 'err'); };
  $('#detToggle').onclick = async () => { const r = await (await api('configs/toggle', { id })).json(); toast(r.enabled ? 'Resumed' : 'Paused'); refresh(); };
  $('#detCopy').onclick = () => navigator.clipboard.writeText(c.uri).then(() => toast('URI copied'));
  $('#detDel').onclick = async () => { if (!confirm(`Delete "${c.name}" and its history?`)) return; await api('configs/delete', { id }); closeDrawer(); toast('Deleted'); refresh(); };
}

/* ---------- import modal ---------- */
const openImport = () => { $('#importModal').classList.remove('hidden'); $('#importUris').focus(); };
const closeImport = () => { $('#importModal').classList.add('hidden'); $('#importUris').value = ''; };
$('#importBtn').addEventListener('click', openImport);
$('#importBtn2').addEventListener('click', openImport);
$('#importClose').addEventListener('click', closeImport);
$('#importCancel').addEventListener('click', closeImport);
$('#importOk').addEventListener('click', async () => {
  const text = $('#importUris').value.trim(); if (!text) return toast('Paste at least one vless:// link', 'err');
  const r = await (await api('configs/add', { text })).json();
  closeImport();
  r.errors?.length ? toast(`Added ${r.added}. Failed: ${r.errors[0]}${r.errors.length > 1 ? ` (+${r.errors.length - 1})` : ''}`, 'err') : toast(`Imported ${r.added} config(s)`);
  refresh();
});

/* ---------- 2FA management ---------- */
let temp2faSecret = '';
async function load2FaStatus() {
  const d = await getJSON('2fa').catch(() => null); if (!d) return;
  const b = $('#twoFaBadge');
  b.textContent = d.enabled ? 'Enabled' : 'Disabled';
  b.className = `badge sm ${d.enabled ? 'ok' : 'dim'}`;
  $('#twoFaDetails').innerHTML = d.enabled
    ? `<button class="hashem-btn hashem-btn-danger" id="twoFaDisableBtn">Disable Two-Factor Authentication</button>`
    : `<button class="hashem-btn hashem-btn-secondary" id="twoFaSetupBtn">Setup 2FA Authentication</button>`;
  temp2faSecret = d.secret;
  $('#twoFaSecretText').textContent = d.secret;
  $('#twoFaOtpLink').href = d.uri;
  $('#twoFaDisableBtn')?.addEventListener('click', async () => {
    const pw = prompt('Enter your admin password to disable 2FA:'); if (!pw) return;
    const r = await api('2fa/disable', { password: pw });
    if (r.ok) { toast('2FA disabled'); load2FaStatus(); }
    else toast((await r.json()).error || 'Failed', 'err');
  });
  $('#twoFaSetupBtn')?.addEventListener('click', () => {
    $('#twoFaModal').classList.remove('hidden'); $('#twoFaVerifyCode').value = ''; $('#twoFaVerifyCode').focus();
  });
}
$('#twoFaClose').addEventListener('click', () => $('#twoFaModal').classList.add('hidden'));
$('#twoFaCancel').addEventListener('click', () => $('#twoFaModal').classList.add('hidden'));
$('#twoFaModal').addEventListener('click', e => { if (e.target.id === 'twoFaModal') $('#twoFaModal').classList.add('hidden'); });
$('#twoFaConfirmBtn').addEventListener('click', async () => {
  const code = $('#twoFaVerifyCode').value.trim();
  if (code.length !== 6) return toast('Enter 6-digit code', 'err');
  const r = await api('2fa/enable', { secret: temp2faSecret, code });
  if (r.ok) { toast('2FA enabled successfully!'); $('#twoFaModal').classList.add('hidden'); load2FaStatus(); }
  else toast((await r.json()).error || 'Verification failed', 'err');
});

/* ---------- clean subscription feed ---------- */
let baseCleanSubUrl = '';
async function loadCleanSub() {
  const d = await getJSON('clean-sub').catch(() => null); if (!d) return;
  baseCleanSubUrl = `${location.origin}${d.url}`;
  updateCleanSubDisplay();
  $('#cleanSubBadge').textContent = d.healthy_count;
  $('#cleanSubCount').textContent = `${d.healthy_count} of ${d.total_count} Nodes`;
}

function updateCleanSubDisplay() {
  if (!baseCleanSubUrl) return;
  const activeBtn = $('#cleanSubFilterPills .sub-filter-btn.active');
  const q = activeBtn ? (activeBtn.dataset.q || '') : '';
  const fullUrl = q ? `${baseCleanSubUrl}?${q}` : baseCleanSubUrl;
  $('#cleanSubUrl').value = fullUrl;
  const qrWrap = $('#cleanSubQr');
  if (qrWrap && window.QRCode) {
    qrWrap.innerHTML = '';
    try {
      new QRCode(qrWrap, {
        text: fullUrl,
        width: 160,
        height: 160,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch (e) {
      console.error('QR render error:', e);
    }
  }
}

$('#cleanSubFilterPills')?.addEventListener('click', e => {
  const btn = e.target.closest('.sub-filter-btn');
  if (!btn) return;
  $$('#cleanSubFilterPills .sub-filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  updateCleanSubDisplay();
});
const openCleanSub = async () => { $('#cleanSubModal').classList.remove('hidden'); await loadCleanSub(); };
const closeCleanSub = () => $('#cleanSubModal').classList.add('hidden');
if ($('#cleanSubBtn')) $('#cleanSubBtn').addEventListener('click', openCleanSub);
if ($('#dashCleanSubBtn')) $('#dashCleanSubBtn').addEventListener('click', openCleanSub);
$('#cleanSubClose').addEventListener('click', closeCleanSub);
$('#cleanSubDone').addEventListener('click', closeCleanSub);
$('#cleanSubModal').addEventListener('click', e => { if (e.target.id === 'cleanSubModal') closeCleanSub(); });
$('#cleanSubCopy').addEventListener('click', () => {
  navigator.clipboard.writeText($('#cleanSubUrl').value).then(() => toast('Clean Subscription URL copied!'));
});
$('#cleanSubRotate').addEventListener('click', async () => {
  if (!confirm('Rotate secret token? Existing clients will lose access until they update the subscription URL.')) return;
  const r = await api('clean-sub/rotate', {}); const d = await r.json();
  if (r.ok) { toast('Token rotated!'); await loadCleanSub(); }
  else toast('Rotate failed', 'err');
});

/* ---------- subscriptions ---------- */
S.subs = [];
const INTERVALS = { 1: '1 hour', 6: '6 hours', 12: '12 hours', 24: '24 hours' };
async function loadSubs() {
  const d = await getJSON('subscriptions').catch(() => null); if (!d) return;
  S.subs = d.subscriptions;
  $('#subBadge').textContent = S.subs.length;
  $('#subBadge').className = `badge sm ${S.subs.length ? 'ok' : 'dim'}`;
  renderSubs();
}
function renderSubs() {
  const next = x => x.last_sync ? Math.max(0, x.last_sync + x.interval_hours * 3600 - Math.floor(Date.now() / 1000)) : 0;
  $('#subList').innerHTML = S.subs.length ? S.subs.map(x => `
    <div class="sub-item" style="${x.enabled ? '' : 'opacity:.6'}">
      <div class="sub-head">
        <div><div class="sub-title">${esc(x.name)} <span class="pill pill-proto">${x.config_count} configs</span></div><div class="sub-url">${esc(x.url.length > 70 ? x.url.slice(0, 60) + '…' + x.url.slice(-8) : x.url)}</div></div>
        ${x.last_sync == null ? '<span class="badge dim"><span class="dot"></span>PENDING</span>' : x.last_ok ? '<span class="badge ok"><span class="dot"></span>SYNCED</span>' : '<span class="badge err"><span class="dot"></span>FAILED</span>'}
      </div>
      <div class="sub-meta">
        <span>${x.last_sync ? `Last: ${ago(x.last_sync)} &middot; ${esc(x.last_msg)}` : 'Never synced'}${x.enabled && x.last_sync ? ` &middot; next in ${dur(next(x))}` : ''}</span>
        <span class="sub-acts">
          <select class="hashem-select" data-sub-int="${x.id}" style="height:28px;width:auto;font-size:12px;padding:0 8px">${Object.entries(INTERVALS).map(([h, l]) => `<option value="${h}" ${+h === x.interval_hours ? 'selected' : ''}>${l}</option>`).join('')}</select>
          <button class="hashem-btn hashem-btn-secondary" style="height:28px;font-size:12px" data-sub-sync="${x.id}">Sync now</button>
          <button class="hashem-btn hashem-btn-ghost" style="height:28px;font-size:12px" data-sub-tog="${x.id}">${x.enabled ? 'Pause' : 'Resume'}</button>
          <button class="hashem-btn hashem-btn-danger" style="height:28px;font-size:12px" data-sub-del="${x.id}">Delete</button>
        </span>
      </div>
      ${x.last_sync && !x.last_ok ? `<div style="font-size:11px;color:var(--er);font-family:var(--font-mono);word-break:break-all">${esc(x.last_msg)}</div>` : ''}
    </div>`).join('') : '<div class="u-mu" style="text-align:center;padding:18px;font-size:12.5px">No subscriptions yet. Add one above.</div>';
}
const openSubs = () => { $('#subModal').classList.remove('hidden'); loadSubs(); $('#subUrl').focus(); };
const closeSubs = () => $('#subModal').classList.add('hidden');
$('#subBtn').addEventListener('click', openSubs);
$('#subClose').addEventListener('click', closeSubs);
$('#subModal').addEventListener('click', e => { if (e.target.id === 'subModal') closeSubs(); });
$('#subAddBtn').addEventListener('click', async e => {
  const url = $('#subUrl').value.trim(); if (!url) return toast('Paste a subscription URL', 'err');
  const b = e.currentTarget; b.disabled = true; b.textContent = 'Fetching…';
  try {
    const r = await api('subscriptions/add', { url, name: $('#subName').value, interval_hours: +$('#subInterval').value });
    const d = await r.json();
    if (r.ok) { toast(`Subscribed: ${d.total} config(s) imported`); $('#subUrl').value = $('#subName').value = ''; await loadSubs(); refresh(); }
    else toast(d.error || 'Failed', 'err');
  } finally { b.disabled = false; b.textContent = 'Add & Sync'; }
});
$('#subList').addEventListener('click', async e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.subSync) {
    t.disabled = true; t.textContent = 'Syncing…';
    const r = await api('subscriptions/sync', { id: t.dataset.subSync }); const d = await r.json();
    r.ok ? toast(`Synced: +${d.added} new, -${d.removed} removed`) : toast(d.error || 'Sync failed', 'err');
    await loadSubs(); refresh();
  } else if (t.dataset.subTog) {
    const x = S.subs.find(v => v.id === t.dataset.subTog);
    await api('subscriptions/update', { id: x.id, enabled: !x.enabled }); loadSubs();
  } else if (t.dataset.subDel) {
    const x = S.subs.find(v => v.id === t.dataset.subDel);
    if (!confirm(`Delete subscription "${x.name}"?\n\nOK = also delete its ${x.config_count} configs\nCancel = keep the configs`)) {
      if (!confirm('Delete only the subscription link and KEEP its configs as manual entries?')) return;
      await api('subscriptions/delete', { id: x.id, delete_configs: false });
    } else await api('subscriptions/delete', { id: x.id, delete_configs: true });
    toast('Subscription removed'); await loadSubs(); refresh();
  }
});
$('#subList').addEventListener('change', async e => {
  const id = e.target.dataset.subInt; if (!id) return;
  const r = await api('subscriptions/update', { id, interval_hours: +e.target.value });
  r.ok ? toast(`Auto-sync every ${INTERVALS[e.target.value]}`) : toast('Update failed', 'err'); loadSubs();
});

/* ---------- incidents ---------- */
async function loadIncidents() {
  const d = await getJSON('incidents').catch(() => null); if (!d) return;
  $('#incTable').innerHTML = d.incidents.length ? d.incidents.map(i => `
    <tr data-open="${i.config_id}" style="cursor:pointer"><td><strong>${esc(i.name)}</strong><br><span class="cfg-addr">${esc(i.addr)}</span></td>
    <td>${when(i.started_at)}</td><td>${i.resolved_at ? when(i.resolved_at) : '<span class="badge err"><span class="dot"></span>ONGOING</span>'}</td>
    <td>${dur((i.resolved_at || Math.floor(Date.now() / 1000)) - i.started_at)}</td>
    <td style="color:var(--er);font-size:11px;font-family:var(--font-mono)">${esc(i.last_error)}</td></tr>`).join('')
    : '<tr><td colspan="5" class="u-mu" style="text-align:center;padding:24px">No incidents recorded.</td></tr>';
}
$('#csvBtn').addEventListener('click', async () => {
  const r = await api('incidents.csv'); const a = document.createElement('a');
  a.href = URL.createObjectURL(await r.blob()); a.download = 'sentinel-incidents.csv'; a.click(); URL.revokeObjectURL(a.href);
});

/* ---------- settings ---------- */
function fillSettings(s) {
  $('#cfgInterval').value = s.interval; $('#cfgThreshold').value = s.threshold; $('#cfgTimeout').value = s.timeout;
  $('#cfgUrl').value = s.url; $('#cfgChat').value = s.chat || '';
  $('#cfgToken').placeholder = s.token_configured ? 'Saved — leave blank to keep' : '123456789:ABCdef…';
  const isHttps = s.use_https === '1' || location.protocol === 'https:';
  const badge = $('#httpsBadge');
  const btn = $('#toggleHttpsBtn');
  const txt = $('#httpsStatusText');
  if (badge) {
    badge.textContent = isHttps ? 'Active' : 'Disabled';
    badge.className = isHttps ? 'badge ok sm' : 'badge dim sm';
  }
  if (btn) btn.textContent = isHttps ? 'Switch to HTTP (Plain)' : 'Enable HTTPS (TLS)';
  if (txt) txt.textContent = isHttps ? `Current mode: HTTPS (${location.origin})` : 'Current mode: HTTP (Plain)';
}

$('#toggleHttpsBtn')?.addEventListener('click', async () => {
  const curHttps = S.data?.settings?.use_https === '1' || location.protocol === 'https:';
  const nextVal = curHttps ? '0' : '1';
  const r = await api('settings', { use_https: nextVal });
  if (r.ok) {
    toast(`HTTPS setting set to ${nextVal === '1' ? 'Enabled' : 'Disabled'}. Restarting service...`);
    setTimeout(() => {
      const targetProto = nextVal === '1' ? 'https:' : 'http:';
      location.href = `${targetProto}//${location.host}${location.pathname}`;
    }, 2000);
  } else {
    toast('Failed updating HTTPS setting', 'err');
  }
});
async function saveSettings() {
  const p = { interval: $('#cfgInterval').value, threshold: $('#cfgThreshold').value, timeout: $('#cfgTimeout').value, url: $('#cfgUrl').value, chat: $('#cfgChat').value.trim() };
  const t = $('#cfgToken').value.trim(); if (t) p.token = t;
  const r = await api('settings', p);
  if (r.ok) { toast('Settings saved'); $('#cfgToken').value = ''; $('#tab-settings').dataset.filled = ''; refresh(); }
  else toast((await r.json()).error || 'Invalid settings', 'err');
}
$('#saveProbe').addEventListener('click', saveSettings);
$('#saveTg').addEventListener('click', saveSettings);
$('#testTg').addEventListener('click', async () => {
  const btn = $('#testTg'); btn.disabled = true; btn.textContent = 'Routing…';
  const tr = $('#tgTrace'); tr.classList.remove('hidden');
  tr.innerHTML = '<div class="u-mu">Attempting delivery via healthy configs (round-robin)…</div>';
  try {
    const res = await (await api('test-telegram', {})).json();
    if (res.ok) {
      toast(`Delivered via ${res.used_node}`);
      tr.innerHTML = `
        <div style="color:var(--ok);font-weight:700;margin-bottom:6px">✔ Delivered via: <b>${esc(res.used_node)}</b> <span class="u-mu">(${esc(res.used_addr)})</span></div>
        <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Route Attempts (${res.attempts.length}):</div>
        ${res.attempts.map(a => `
          <div style="font-family:var(--font-mono);font-size:11px;padding:3px 0;border-top:1px solid var(--ln)">
            <span style="color:${a.ok ? 'var(--ok)' : 'var(--er)'}">${a.ok ? '✔' : '✖'}</span> <b>${esc(a.node)}</b> <span class="pill ${a.sub_name ? 'pill-sub' : 'pill-port'}" style="font-size:10px;padding:1px 5px">${a.sub_name ? '? SUB: ' + esc(a.sub_name) : 'Manual'}</span>
            ${a.ms != null ? `<span style="color:var(--dim)">${a.ms}ms</span>` : ''}
            ${a.error ? `<span style="color:var(--er)">(${esc(a.error)})</span>` : ''}
          </div>`).join('')}`;
    } else {
      toast('Failed to deliver alert', 'err');
      tr.innerHTML = `
        <div style="color:var(--er);font-weight:700;margin-bottom:6px">✖ Delivery Failed across all routes</div>
        <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Attempts (${(res.attempts||[]).length}):</div>
        ${(res.attempts||[]).map(a => `
          <div style="font-family:var(--font-mono);font-size:11px;padding:3px 0;border-top:1px solid var(--ln)">
            <span style="color:var(--er)">✖</span> <b>${esc(a.node || 'Route')}</b>
            ${a.error ? `<span style="color:var(--er)">: ${esc(a.error)}</span>` : ''}
          </div>`).join('')}`;
    }
  } catch(e) {
    toast('Communication error', 'err');
    tr.innerHTML = `<div style="color:var(--er)">Error: ${esc(e.message)}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Send Test Alert';
  }
});
$('#pwSave').addEventListener('click', async () => {
  const r = await api('password', { old: $('#pwOld').value, new: $('#pwNew').value });
  if (r.ok) { toast('Password changed'); $('#pwOld').value = $('#pwNew').value = ''; } else toast((await r.json()).error, 'err');
});
$$('.acc-btn').forEach(b => b.addEventListener('click', () => { setAccent(b.dataset.acc); api('settings', { accent: b.dataset.acc }); }));
function setAccent(a) { document.documentElement.dataset.acc = a; localStorage.setItem('sentinel_accent', a); $$('.acc-btn').forEach(x => x.classList.toggle('selected', x.dataset.acc === a)); if (S.tab === 'dashboard') drawHistory(); }

/* ---------- theme / sidebar ---------- */
$('#themeBtn').addEventListener('click', () => {
  const n = document.documentElement.dataset.t === 'light' ? 'dark' : 'light';
  document.documentElement.dataset.t = document.body.dataset.t = n; localStorage.setItem('sentinel_theme', n);
  if (S.tab === 'dashboard') drawHistory();
});
$('#sbToggle').addEventListener('click', () => {
  const on = document.documentElement.dataset.sb !== '1';
  document.documentElement.dataset.sb = on ? '1' : '0'; localStorage.setItem('sentinel_sb', on ? '1' : '0');
  $('#sbToggle').setAttribute('aria-pressed', on);
});
$('#checkNowBtn').addEventListener('click', async () => { toast('Probing all configs…'); await api('check-now', {}); setTimeout(refresh, 2500); });

/* ---------- command palette ---------- */
const palItems = () => [
  ...['dashboard', 'configs', 'speedtest', 'incidents', 'settings'].map(t => ({ g: 'Go to', t: TITLES[t][0], run: () => switchTab(t) })),
  { g: 'Actions', t: 'Import VLESS configs', run: () => { switchTab('configs'); openImport(); } },
  { g: 'Actions', t: 'Get Clean Subscription link', run: () => openCleanSub() },
  { g: 'Actions', t: 'Manage subscriptions', run: () => { switchTab('configs'); openSubs(); } },
  { g: 'Actions', t: 'Probe all now', run: () => $('#checkNowBtn').click() },
  { g: 'Actions', t: 'Toggle theme', run: () => $('#themeBtn').click() },
  { g: 'Actions', t: 'Export incidents CSV', run: () => $('#csvBtn').click() },
  ...(S.data?.configs || []).map(c => ({ g: 'Configs', t: c.name, sub: c.addr, run: () => openDrawer(c.id) })),
];
let palSel = 0, palRows = [];
function palRender() {
  const q = $('#palInput').value.toLowerCase();
  palRows = palItems().filter(i => !q || (i.t + ' ' + (i.sub || '')).toLowerCase().includes(q));
  palSel = Math.min(palSel, Math.max(0, palRows.length - 1));
  let g = '';
  $('#palList').innerHTML = palRows.length ? palRows.map((i, n) => { const h = i.g !== g ? `<div class="pal-g">${g = i.g}</div>` : ''; return `${h}<div class="pal-it ${n === palSel ? 'on' : ''}" data-n="${n}"><span class="pal-t">${esc(i.t)}</span>${i.sub ? `<span class="pal-gt">${esc(i.sub)}</span>` : ''}</div>`; }).join('') : '<div class="pal-none">No results</div>';
  $('#palList .on')?.scrollIntoView({ block: 'nearest' });
}
function palOpen() { $('#palOv').hidden = false; $('#palInput').value = ''; palSel = 0; palRender(); $('#palInput').focus(); }
function palClose() { $('#palOv').hidden = true; }
function palRun(n) { const i = palRows[n]; if (i) { palClose(); i.run(); } }
$('#palBtn').addEventListener('click', palOpen);
$('#palEsc').addEventListener('click', palClose);

// SP-Test triggers
document.addEventListener('click', async e => {
  const btn = e.target.closest('[data-sp-test]');
  if (!btn) return;
  e.stopPropagation();
  const id = btn.dataset.spTest;
  btn.disabled = true;
  btn.textContent = '⚡ 100MB...';
  try {
    const res = await (await api('speedtest', { id })).json();
    if (res.ok) {
      toast(`⚡ Download Speed: ${res.mbps} Mbps (${res.elapsed}s)`);
      await refresh();
      if (S.tab === 'speedtest') renderSpeedTestTab();
    } else {
      toast(res.error || 'Speed test failed', 'err');
    }
  } catch(ex) {
    toast('Speed test communication error', 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = '⚡ SP-Test 100MB';
  }
});

$('#spTestAllBtn')?.addEventListener('click', async () => {
  toast('Started 100MB speed test across all healthy nodes...');
  const res = await (await api('speedtest/all', {})).json();
  if (res.ok) toast('Running 100MB tests in background. Cards will update sequentially.');
  else toast(res.error || 'Could not start', 'err');
});
$('#palOv').addEventListener('click', e => { if (e.target.id === 'palOv') palClose(); });
$('#palInput').addEventListener('input', () => { palSel = 0; palRender(); });
$('#palList').addEventListener('click', e => { const r = e.target.closest('.pal-it'); if (r) palRun(+r.dataset.n); });
$('#palInput').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { palSel = Math.min(palRows.length - 1, palSel + 1); palRender(); e.preventDefault(); }
  else if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); palRender(); e.preventDefault(); }
  else if (e.key === 'Enter') palRun(palSel);
});
addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('#subModal').classList.contains('hidden')) { closeSubs(); return; }
  if (e.key === 'Escape' && !$('#cleanSubModal').classList.contains('hidden')) { closeCleanSub(); return; }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k' && !$('#app').classList.contains('hidden')) { e.preventDefault(); $('#palOv').hidden ? palOpen() : palClose(); }
  if (e.key === 'Escape') { if ($('#supCard') && !$('#supCard').hidden) supHide('close'); else if (!$('#palOv').hidden) palClose(); else if (S.drawerId) closeDrawer(); else if (!$('#importModal').classList.contains('hidden')) closeImport(); }
});

/* ---------- login background: kinetic grid (Hashem exact) ---------- */
(function(){
  const CELL_SIZE = 55, INFLUENCE_RADIUS = 260, MAX_WARP = 24;
  const DOT_SPACING = 28, LERP_SPEED = 0.08;
  const LINE_BASE = { r: 255, g: 255, b: 255, a: 0.13 };
  const NODE_BASE_RADIUS = 1.8, NODE_ACTIVE_RADIUS = 3.2;
  const lerpN = (a,b,t) => a + (b - a) * t;
  const lerpColor = (base,active,t) => {
    const r = Math.round(lerpN(base.r,active.r,t)), g = Math.round(lerpN(base.g,active.g,t)),
          b = Math.round(lerpN(base.b,active.b,t)), a = lerpN(base.a,active.a,t);
    return 'rgba('+r+','+g+','+b+','+a.toFixed(3)+')';
  };
  const canvas = document.getElementById('kineticGrid');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, mouse = {x:-9999,y:-9999}, targetMouse = {x:-9999,y:-9999}, ripples = [];
  const theme = { bg:'#09090b', lineActive:{r:56,g:189,b:248,a:0.9},
    nodeActive:{r:56,g:189,b:248,a:1.0}, glow:'56,189,248', ripple:'56,189,248' };
  function setSize(){ W = innerWidth; H = innerHeight; canvas.width = W; canvas.height = H;
    if (mouse.x === -9999) { mouse = {x:W/2,y:H/2}; targetMouse = {x:W/2,y:H/2}; } }
  addEventListener('resize', setSize); setSize();
  addEventListener('mousemove', e => { targetMouse.x = e.clientX; targetMouse.y = e.clientY; });
  addEventListener('click', e => { ripples.push({x:e.clientX,y:e.clientY,radius:0,opacity:1,born:performance.now()}); });
  function getWarpedPoint(gx,gy,col,row,cols,rows){
    const edgeMargin = 1.5;
    const colPin = Math.min(col/edgeMargin,(cols-1-col)/edgeMargin,1);
    const rowPin = Math.min(row/edgeMargin,(rows-1-row)/edgeMargin,1);
    const pinFactor = colPin*colPin*rowPin*rowPin;
    const dx = gx-mouse.x, dy = gy-mouse.y, dist = Math.sqrt(dx*dx+dy*dy);
    const proximity = Math.max(0,1-dist/INFLUENCE_RADIUS)*pinFactor;
    let rx = 0, ry = 0;
    for (const r of ripples){
      const rdx = gx-r.x, rdy = gy-r.y, rdist = Math.sqrt(rdx*rdx+rdy*rdy);
      const waveWidth = 55, diff = rdist-r.radius;
      if (Math.abs(diff) < waveWidth){
        const strength = (1-Math.abs(diff)/waveWidth)*r.opacity*18*pinFactor;
        const angle = Math.atan2(rdy,rdx), sign = diff < 0 ? -1 : 1;
        rx += Math.cos(angle)*strength*sign*-1; ry += Math.sin(angle)*strength*sign*-1;
      }
    }
    if (dist < INFLUENCE_RADIUS && dist > 0 && pinFactor > 0){
      const t = dist/INFLUENCE_RADIUS;
      const eased = t < 0.01 ? 0 : (1-t)*(1-t)*Math.min(1,dist/60);
      const warpAmt = eased*MAX_WARP*pinFactor, angle = Math.atan2(dy,dx);
      return { pt:{x:gx-Math.cos(angle)*warpAmt+rx, y:gy-Math.sin(angle)*warpAmt+ry}, proximity };
    }
    return { pt:{x:gx+rx, y:gy+ry}, proximity };
  }
  function draw(now){
    ctx.clearRect(0,0,W,H); ctx.fillStyle = theme.bg; ctx.fillRect(0,0,W,H);
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    for (let x = DOT_SPACING/2; x < W; x += DOT_SPACING)
      for (let y = DOT_SPACING/2; y < H; y += DOT_SPACING){
        ctx.beginPath(); ctx.arc(x,y,0.7,0,Math.PI*2); ctx.fill();
      }
    for (let i = ripples.length-1; i >= 0; i--){
      const r = ripples[i], age = (now-r.born)/1000;
      r.radius = Math.max(0,age*400); r.opacity = Math.max(0,1-age*1.2);
      if (r.opacity <= 0) ripples.splice(i,1);
    }
    const cols = Math.max(2,Math.ceil(W/CELL_SIZE))+1, rows = Math.max(2,Math.ceil(H/CELL_SIZE))+1;
    const cellW = W/(cols-1), cellH = H/(rows-1), pts = [], prox = [];
    for (let row = 0; row < rows; row++){
      pts[row] = []; prox[row] = [];
      for (let col = 0; col < cols; col++){
        const wp = getWarpedPoint(col*cellW,row*cellH,col,row,cols,rows);
        pts[row][col] = wp.pt; prox[row][col] = wp.proximity;
      }
    }
    const drawSeg = (p1,p2,pr1,pr2) => {
      const avg = (pr1+pr2)/2, t = avg*avg*(3-2*avg);
      ctx.beginPath(); ctx.moveTo(p1.x,p1.y); ctx.lineTo(p2.x,p2.y);
      ctx.strokeStyle = lerpColor(LINE_BASE,theme.lineActive,t);
      ctx.lineWidth = lerpN(0.8,1.5,t); ctx.stroke();
    };
    ctx.lineCap = 'butt';
    for (let row = 0; row < rows; row++)
      for (let col = 0; col < cols-1; col++) drawSeg(pts[row][col],pts[row][col+1],prox[row][col],prox[row][col+1]);
    for (let col = 0; col < cols; col++)
      for (let row = 0; row < rows-1; row++) drawSeg(pts[row][col],pts[row+1][col],prox[row][col],prox[row+1][col]);
    for (let row = 0; row < rows; row++)
      for (let col = 0; col < cols; col++){
        const p = pts[row][col], pr = prox[row][col], t = pr*pr*(3-2*pr);
        const r = lerpN(NODE_BASE_RADIUS,NODE_ACTIVE_RADIUS,t);
        if (t > 0.3){
          const glowR = r+lerpN(0,6,(t-0.3)/0.7);
          const grd = ctx.createRadialGradient(p.x,p.y,r*0.5,p.x,p.y,glowR);
          grd.addColorStop(0,'rgba('+theme.glow+','+(t*0.3).toFixed(3)+')');
          grd.addColorStop(1,'rgba('+theme.glow+',0)');
          ctx.beginPath(); ctx.arc(p.x,p.y,glowR,0,Math.PI*2);
          ctx.fillStyle = grd; ctx.fill();
        }
        ctx.beginPath(); ctx.arc(p.x,p.y,r,0,Math.PI*2);
        ctx.fillStyle = lerpColor({r:255,g:255,b:255,a:0.2},theme.nodeActive,t); ctx.fill();
      }
    for (const r of ripples){
      ctx.beginPath(); ctx.arc(r.x,r.y,Math.max(0,r.radius),0,Math.PI*2);
      ctx.strokeStyle = 'rgba('+theme.ripple+','+(r.opacity*0.28).toFixed(3)+')';
      ctx.lineWidth = 1.5; ctx.stroke();
    }
  }
  (function animate(now){
    mouse.x = lerpN(mouse.x,targetMouse.x,LERP_SPEED);
    mouse.y = lerpN(mouse.y,targetMouse.y,LERP_SPEED);
    draw(now); requestAnimationFrame(animate);
  })(0);
})();

/* ---------- boot ---------- */
(async function boot() {
  const a = localStorage.getItem('sentinel_accent'); if (a) setAccent(a); loadCleanSub(); load2FaStatus();
  const r = await api('dashboard').catch(() => null);
  if (r?.ok) {
    S.data = await r.json(); showApp(); render();
    const h = location.hash.slice(1); switchTab(TITLES[h] ? h : 'dashboard');
    refresh();
  } else showLogin();
})();
