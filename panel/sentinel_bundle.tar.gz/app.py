#!/usr/bin/env python3
"""Sentinel: VLESS health monitor daemon with SQLite storage and Telegram alerts."""
import base64, gzip, json, os, sys, time, hmac, hashlib, secrets, subprocess, threading, re, random, socket, sqlite3
import urllib.parse as up
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from concurrent.futures import ThreadPoolExecutor

D = os.path.dirname(os.path.abspath(__file__))
DB_FILE = D + "/sentinel.db"
XCFG = D + "/xray.json"
XBIN = D + "/xray"
CRED = D + "/credentials.txt"
STATIC_DIR = D + "/static"
INDEX_FILE = D + "/index.html"
BASE_PORT = 41000

lock = threading.RLock()
wake = threading.Event()
xp = None
fails_by_ip = {}

DEF_SETTINGS = {
    "interval": "30",
    "threshold": "3",
    "timeout": "8",
    "url": "http://cp.cloudflare.com/generate_204",
    "token": "",
    "chat": "",
    "theme": "dark",
    "accent": "sky",
    "use_https": "0",
}

# ---------- Database ----------
def get_db():
    conn = sqlite3.connect(DB_FILE, timeout=10, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn

db_conn = None

def init_db():
    global db_conn
    db_conn = get_db()
    with db_conn:
        db_conn.executescript("""
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS configs (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            uri TEXT NOT NULL UNIQUE,
            addr TEXT NOT NULL,
            port INTEGER NOT NULL UNIQUE,
            protocol TEXT DEFAULT 'vless',
            network TEXT DEFAULT 'tcp',
            security TEXT DEFAULT 'none',
            enabled INTEGER DEFAULT 1,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_id TEXT NOT NULL,
            ok INTEGER NOT NULL,
            latency_ms INTEGER,
            error TEXT,
            checked_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_checks_cfg_time ON checks(config_id, checked_at);
        CREATE INDEX IF NOT EXISTS idx_checks_time ON checks(checked_at);
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_id TEXT NOT NULL,
            started_at INTEGER NOT NULL,
            resolved_at INTEGER,
            last_error TEXT,
            alert_sent INTEGER DEFAULT 0,
            resolved_alert_sent INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_incidents_cfg ON incidents(config_id);
        CREATE TABLE IF NOT EXISTS subscriptions (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            url TEXT NOT NULL UNIQUE,
            interval_hours INTEGER NOT NULL DEFAULT 6,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_sync INTEGER,
            last_ok INTEGER,
            last_msg TEXT DEFAULT '',
            config_count INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pending_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        """)
        if "sub_id" not in [r[1] for r in db_conn.execute("PRAGMA table_info(configs)")]:
            db_conn.execute("ALTER TABLE configs ADD COLUMN sub_id TEXT")
        if "ok_iran" not in [r[1] for r in db_conn.execute("PRAGMA table_info(checks)")]:
            db_conn.execute("ALTER TABLE checks ADD COLUMN ok_iran INTEGER DEFAULT 1")
        cfg_cols = [r[1] for r in db_conn.execute("PRAGMA table_info(configs)")]
        if "last_speed_mbps" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN last_speed_mbps REAL")
        if "last_speed_time" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN last_speed_time INTEGER")
        inc_cols = [r[1] for r in db_conn.execute("PRAGMA table_info(incidents)")]
        if "last_reminder_at" not in inc_cols:
            db_conn.execute("ALTER TABLE incidents ADD COLUMN last_reminder_at INTEGER DEFAULT 0")
        if "country_code" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN country_code TEXT DEFAULT ''")
        if "country_name" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN country_name TEXT DEFAULT ''")
        db_conn.execute('''
        CREATE TABLE IF NOT EXISTS geo_cache (
            ip TEXT PRIMARY KEY,
            country_code TEXT NOT NULL,
            country_name TEXT NOT NULL,
            updated_at INTEGER NOT NULL
        );
        ''')
        # Initialize defaults
        for k, v in DEF_SETTINGS.items():
            db_conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
        # Panel credentials
        cur = db_conn.execute("SELECT value FROM meta WHERE key='sub_token'")
        if not cur.fetchone():
            db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sub_token', ?)", (secrets.token_hex(8),))

        cur = db_conn.execute("SELECT value FROM meta WHERE key='secret'")
        if not cur.fetchone():
            pw = secrets.token_urlsafe(12)
            salt = secrets.token_hex(8)
            pwh = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100000).hex()
            secret = secrets.token_hex(32)
            path = secrets.token_hex(6)
            port = str(free_port(30000, 39999))
            for k, val in [("secret", secret), ("path", path), ("port", port), ("salt", salt), ("pw", pwh)]:
                db_conn.execute("INSERT INTO meta (key, value) VALUES (?, ?)", (k, val))
            with open(CRED, "w") as f:
                f.write(f"path=/{path}/\nport={port}\npassword={pw}\n")
            os.chmod(CRED, 0o600)

def free_port(lo, hi):
    for _ in range(50):
        p = random.randint(lo, hi)
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return 39878

def get_public_ip():
    ip = get_meta("public_ip")
    if ip:
        return ip
    for p in ("https://api.ipify.org", "https://icanhazip.com", "https://ifconfig.me"):
        try:
            r = subprocess.run(["curl", "-fsSL", "--max-time", "3", p], capture_output=True, text=True)
            v = r.stdout.strip()
            if v and re.match(r"^\d{1,3}(\.\d{1,3}){3}$", v):
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('public_ip', ?)", (v,))
                return v
        except Exception:
            pass
    return "127.0.0.1"

def get_meta(k):
    with lock:
        r = db_conn.execute("SELECT value FROM meta WHERE key=?", (k,)).fetchone()
    return r["value"] if r else None

def get_settings():
    with lock:
        return {r["key"]: r["value"] for r in db_conn.execute("SELECT key, value FROM settings").fetchall()}

def hashpw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100000).hex()

# ---------- Multi-Protocol URI Parsers & Geo-IP ----------

def flag_to_cc(text):
    if not text: return None
    for i in range(len(text) - 1):
        c1, c2 = ord(text[i]), ord(text[i+1])
        if 0x1F1E6 <= c1 <= 0x1F1FF and 0x1F1E6 <= c2 <= 0x1F1FF:
            return (chr(c1 - 127397) + chr(c2 - 127397)).upper()
    return None

def country_flag(cc):
    if not cc or len(cc) != 2 or cc.upper() == "XX":
        return "🌐"
    return chr(ord(cc[0].upper()) + 127397) + chr(ord(cc[1].upper()) + 127397)

COUNTRY_NAMES = {
    "DE": "Germany", "FI": "Finland", "FR": "France", "NL": "Netherlands",
    "US": "United States", "GB": "United Kingdom", "TR": "Turkey", "IR": "Iran",
    "CA": "Canada", "SE": "Sweden", "RU": "Russia", "SG": "Singapore",
    "AE": "UAE", "PL": "Poland", "IT": "Italy", "ES": "Spain",
    "CH": "Switzerland", "AT": "Austria", "JP": "Japan", "KR": "South Korea",
    "AU": "Australia", "RO": "Romania", "UA": "Ukraine", "NO": "Norway"
}

COUNTRY_KW = {
    "germany": "DE", "deutschland": "DE", "finland": "FI", "france": "FR",
    "netherlands": "NL", "holland": "NL", "amsterdam": "NL",
    "united states": "US", "usa": "US", "america": "US",
    "united kingdom": "GB", "uk": "GB", "london": "GB", "england": "GB",
    "turkey": "TR", "turkiye": "TR", "istanbul": "TR",
    "iran": "IR", "tehran": "IR",
    "canada": "CA", "sweden": "SE", "russia": "RU", "singapore": "SG",
    "uae": "AE", "dubai": "AE", "poland": "PL", "italy": "IT",
    "spain": "ES", "switzerland": "CH", "austria": "AT",
    "japan": "JP", "tokyo": "JP", "korea": "KR", "australia": "AU"
}

def resolve_country(host, name=""):
    # 1. Flag in name
    cc = flag_to_cc(name)
    if cc:
        return cc, COUNTRY_NAMES.get(cc, cc)

    # 2. Keyword in name
    n_low = (name or "").lower()
    for kw, c in COUNTRY_KW.items():
        if kw in n_low or f"[{c.lower()}]" in n_low or f"({c.lower()})" in n_low or f" {c.lower()} " in f" {n_low} ":
            return c, COUNTRY_NAMES.get(c, c)

    # 3. Resolve IP
    ip = host
    if not re.fullmatch(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", host):
        try:
            ip = socket.gethostbyname(host)
        except Exception:
            return "XX", "Unknown"

    with lock:
        r = db_conn.execute("SELECT country_code, country_name FROM geo_cache WHERE ip=?", (ip,)).fetchone()
        if r:
            return r["country_code"], r["country_name"]

    try:
        url = f"http://ip-api.com/json/{ip}?fields=countryCode,country"
        req = urllib.request.Request(url, headers={"User-Agent": "curl/7.88"})
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            data = json.loads(resp.read().decode())
            c_code = data.get("countryCode", "XX")
            c_name = data.get("country", "Unknown")
            if c_code and c_code != "XX":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO geo_cache (ip, country_code, country_name, updated_at) VALUES (?, ?, ?, ?)",
                                   (ip, c_code, c_name, int(time.time())))
                    db_conn.commit()
                return c_code, c_name
    except Exception:
        pass

    return "XX", "Unknown"

def _build_stream_settings(net, sec, q, host_default):
    net = net or "tcp"
    sec = sec or "none"
    ss = {"network": net, "security": sec}
    if sec == "tls":
        t = {
            "serverName": q.get("sni") or q.get("host") or host_default,
            "allowInsecure": q.get("allowInsecure") in ("1", "true")
        }
        if q.get("fp"): t["fingerprint"] = q["fp"]
        if q.get("alpn"): t["alpn"] = q["alpn"].split(",")
        ss["tlsSettings"] = t
    elif sec == "reality":
        ss["realitySettings"] = {
            "serverName": q.get("sni", ""),
            "fingerprint": q.get("fp", "chrome"),
            "publicKey": q.get("pbk", ""),
            "shortId": q.get("sid", ""),
            "spiderX": q.get("spx", "")
        }
    elif sec != "none":
        raise ValueError("Unsupported security: " + sec)

    path = q.get("path", "/")
    h_hdr = q.get("host", "")
    if net == "ws":
        ss["wsSettings"] = {"path": path, "headers": {"Host": h_hdr} if h_hdr else {}}
    elif net == "grpc":
        ss["grpcSettings"] = {"serviceName": q.get("serviceName", ""), "multiMode": q.get("mode") == "multi"}
    elif net == "httpupgrade":
        ss["httpupgradeSettings"] = {"path": path, "host": h_hdr}
    elif net in ("xhttp", "splithttp"):
        ss["network"] = "xhttp"
        ss["xhttpSettings"] = {"path": path, "host": h_hdr, "mode": q.get("mode", "auto")}
    elif net == "tcp" and q.get("headerType") == "http":
        ss["tcpSettings"] = {"header": {"type": "http", "request": {"path": [path], "headers": {"Host": [h_hdr]}}}}
    elif net != "tcp":
        raise ValueError("Unsupported transport: " + net)

    return ss

def parse_vless(uri):
    """Backward-compatible VLESS parser returning (urlparse_obj, query_dict, name)"""
    u = up.urlparse(uri.strip())
    if u.scheme != "vless" or not u.hostname or not u.username or not u.port:
        raise ValueError("Invalid VLESS URI format")
    q = {k: v[0] for k, v in up.parse_qs(u.query).items()}
    name = up.unquote(u.fragment) or f"{u.hostname}:{u.port}"
    return u, q, name

def parse_proxy_uri(uri):
    s = uri.strip()
    if s.startswith("vless://"):
        u, q, name = parse_vless(s)
        return {
            "protocol": "vless", "name": name, "addr": f"{u.hostname}:{u.port}",
            "host": u.hostname, "port": u.port, "uuid": u.username,
            "network": q.get("type", "tcp"), "security": q.get("security", "none"), "q": q
        }
    elif s.startswith("trojan://"):
        u = up.urlparse(s)
        if not u.hostname or not u.username or not u.port:
            raise ValueError("Invalid Trojan URI format")
        q = {k: v[0] for k, v in up.parse_qs(u.query).items()}
        name = up.unquote(u.fragment) or f"{u.hostname}:{u.port}"
        return {
            "protocol": "trojan", "name": name, "addr": f"{u.hostname}:{u.port}",
            "host": u.hostname, "port": u.port, "password": u.username,
            "network": q.get("type", "tcp"), "security": q.get("security", "tls"), "q": q
        }
    elif s.startswith("ss://"):
        raw = s[5:]
        name = ""
        if "#" in raw: raw, frag = raw.split("#", 1); name = up.unquote(frag)
        q = {}
        if "?" in raw: raw, qs = raw.split("?", 1); q = {k: v[0] for k, v in up.parse_qs(qs).items()}
        if "@" in raw:
            uinfo, hport = raw.split("@", 1)
            try:
                dec = base64.b64decode(uinfo + "=" * (-len(uinfo) % 4), altchars=b"-_").decode("utf-8")
                method, password = dec.split(":", 1) if ":" in dec else uinfo.split(":", 1)
            except Exception:
                method, password = uinfo.split(":", 1)
            host, port_s = hport.rsplit(":", 1)
            port = int(port_s)
        else:
            dec = base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8")
            uinfo, hport = dec.split("@", 1)
            method, password = uinfo.split(":", 1)
            host, port_s = hport.rsplit(":", 1)
            port = int(port_s)
        return {
            "protocol": "shadowsocks", "name": name or f"{host}:{port}",
            "addr": f"{host}:{port}", "host": host, "port": port,
            "method": method, "password": password, "network": "tcp", "security": "none", "q": q
        }
    elif s.startswith("vmess://"):
        raw = s[8:]
        data = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8"))
        host = data.get("add", "")
        port = int(data.get("port", 443))
        q = {
            "host": data.get("host", ""),
            "path": data.get("path", "/"),
            "sni": data.get("sni") or data.get("host") or host,
            "alpn": data.get("alpn", ""),
            "type": data.get("type", "none")
        }
        return {
            "protocol": "vmess", "name": data.get("ps") or f"{host}:{port}",
            "addr": f"{host}:{port}", "host": host, "port": port,
            "uuid": data.get("id", ""), "aid": int(data.get("aid", 0) or 0),
            "scy": data.get("scy", "auto") or "auto", "network": data.get("net", "tcp") or "tcp",
            "security": data.get("tls", "none") or "none", "q": q
        }
    raise ValueError(f"Unsupported URI scheme: {s.split('://')[0] if '://' in s else s[:15]}")

def outbound_for(c):
    info = parse_proxy_uri(c["uri"])
    proto = info["protocol"]
    q = info.get("q", {})

    if proto == "vless":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        user = {"id": info["uuid"], "encryption": q.get("encryption", "none")}
        if q.get("flow"): user["flow"] = q["flow"]
        return {
            "tag": "o_" + c["id"],
            "protocol": "vless",
            "settings": {"vnext": [{"address": info["host"], "port": info["port"], "users": [user]}]},
            "streamSettings": ss
        }
    elif proto == "trojan":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        return {
            "tag": "o_" + c["id"],
            "protocol": "trojan",
            "settings": {"servers": [{"address": info["host"], "port": info["port"], "password": info["password"]}]},
            "streamSettings": ss
        }
    elif proto == "shadowsocks":
        return {
            "tag": "o_" + c["id"],
            "protocol": "shadowsocks",
            "settings": {"servers": [{
                "address": info["host"],
                "port": info["port"],
                "method": info["method"],
                "password": info["password"],
                "uot": True
            }]}
        }
    elif proto == "vmess":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        return {
            "tag": "o_" + c["id"],
            "protocol": "vmess",
            "settings": {"vnext": [{
                "address": info["host"],
                "port": info["port"],
                "users": [{"id": info["uuid"], "alterId": info["aid"], "security": info["scy"]}]
            }]},
            "streamSettings": ss
        }
    raise ValueError(f"Unsupported protocol: {proto}")

def gen_xray_config(configs):
    inbounds = [{
        "tag": "i_" + c["id"],
        "listen": "127.0.0.1",
        "port": c["port"],
        "protocol": "socks",
        "settings": {"udp": False}
    } for c in configs]
    outbounds = [outbound_for(c) for c in configs]
    rules = [{
        "type": "field",
        "inboundTag": ["i_" + c["id"]],
        "outboundTag": "o_" + c["id"]
    } for c in configs]
    return {
        "log": {"loglevel": "warning"},
        "inbounds": inbounds,
        "outbounds": outbounds,
        "routing": {"rules": rules}
    }

def restart_xray():
    global xp
    with lock:
        if xp and xp.poll() is None:
            xp.terminate()
            try: xp.wait(4)
            except Exception: xp.kill()
        xp = None
        cur = db_conn.execute("SELECT id, uri, port FROM configs WHERE enabled=1")
        configs = [dict(r) for r in cur.fetchall()]
        if not configs:
            return
        if not os.path.exists(XBIN):
            return
        cfg = gen_xray_config(configs)
        with open(XCFG, "w") as f:
            json.dump(cfg, f, indent=2)
        xp = subprocess.Popen([XBIN, "run", "-c", XCFG], stdout=open(D + "/xray.log", "ab"), stderr=subprocess.STDOUT)
    time.sleep(0.8)

# ---------- Health Checking ----------
def probe_one(c, timeout, intl_url, iran_url="https://aparat.com"):
    # Probe 1: International endpoint
    cmd1 = ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code} %{time_total}",
            "-x", f"socks5h://127.0.0.1:{c['port']}", "--max-time", str(timeout), intl_url]
    r1 = subprocess.run(cmd1, capture_output=True, text=True)
    out1 = r1.stdout.split()
    ok_intl, ms_intl, err_intl = False, None, ""
    if r1.returncode == 0 and out1 and out1[0][0] in "23":
        ok_intl = True
        ms_intl = int(float(out1[1]) * 1000)
    else:
        err_intl = (r1.stderr.strip() or ("HTTP " + (out1[0] if out1 else "none")))[:180]

    # Probe 2: Domestic Iran endpoint to detect National Intranet (ملی شدن)
    ok_iran = 0
    try:
        cmd2 = ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}",
                "-x", f"socks5h://127.0.0.1:{c['port']}", "--max-time", "4", iran_url]
        r2 = subprocess.run(cmd2, capture_output=True, text=True, timeout=5)
        code2 = r2.stdout.strip()
        if r2.returncode == 0 and code2 and code2[0] in "23":
            ok_iran = 1
    except Exception:
        ok_iran = 0

    return c["id"], ok_intl, ms_intl, err_intl, ok_iran

tg_rr_idx = 0

def send_telegram(text, reply_markup=None, record_trace=False):
    global tg_rr_idx
    s = get_settings()
    tok, chat = s.get("token", ""), s.get("chat", "")
    if not tok or not chat:
        return (False, None, [{"error": "token or chat_id missing"}]) if record_trace else False
    
    post_params = {"chat_id": chat, "text": text, "parse_mode": "HTML", "disable_web_page_preview": "true"}
    if reply_markup:
        post_params["reply_markup"] = json.dumps(reply_markup) if isinstance(reply_markup, dict) else str(reply_markup)
    body = up.urlencode(post_params)
    cfg = f'url = "https://api.telegram.org/bot{tok}/sendMessage"\ndata = "{body}"\n'

    with lock:
        # Most recent probe for each enabled config
        rows = db_conn.execute("""
            SELECT c.id, c.name, c.addr, c.port, s.name as sub_name FROM configs c
            LEFT JOIN subscriptions s ON s.id = c.sub_id
            JOIN (
                SELECT config_id, ok, MAX(checked_at) AS last_t
                FROM checks GROUP BY config_id
            ) ch ON ch.config_id = c.id
            WHERE c.enabled=1 AND ch.ok=1
            ORDER BY c.id ASC
        """).fetchall()
        healthy = [dict(r) for r in rows]

    attempts = []
    delivered = False
    used_cfg = None

    if healthy:
        # Round-robin starting point
        n = len(healthy)
        with lock:
            start = tg_rr_idx % n
        ordered = healthy[start:] + healthy[:start]

        for c in ordered:
            t0 = time.time()
            cmd = ["curl", "-sS", "--max-time", "12", "-K", "-", "-x", f"socks5h://127.0.0.1:{c['port']}"]
            try:
                r = subprocess.run(cmd, input=cfg, capture_output=True, text=True, timeout=15)
                ms = int((time.time() - t0) * 1000)
                if '"ok":true' in r.stdout:
                    delivered = True
                    used_cfg = c
                    with lock:
                        tg_rr_idx = (tg_rr_idx + 1) % 1000000
                    attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": True, "ms": ms})
                    break
                else:
                    err = (r.stderr.strip() or r.stdout.strip() or "rejected")[:120]
                    attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": False, "ms": ms, "error": err})
            except Exception as ex:
                attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": False, "error": str(ex)[:120]})

    if not delivered:
        t0 = time.time()
        cmd = ["curl", "-sS", "--max-time", "10", "-K", "-"]
        try:
            r = subprocess.run(cmd, input=cfg, capture_output=True, text=True, timeout=12)
            ms = int((time.time() - t0) * 1000)
            if '"ok":true' in r.stdout:
                delivered = True
                used_cfg = {"name": "Host Direct", "addr": "Direct", "port": 0}
                attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": True, "ms": ms})
            else:
                err = (r.stderr.strip() or r.stdout.strip() or "failed")[:120]
                attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": False, "ms": ms, "error": err})
        except Exception as ex:
            attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": False, "error": str(ex)[:120]})

    if record_trace:
        return delivered, used_cfg, attempts
    return delivered


# ---------- Telegram Bot (2-Way Commands & Backups) ----------
# ---------- TOTP (RFC 6238) ----------
def generate_totp_secret():
    # 16-char base32 string (80 bits)
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    return "".join(secrets.choice(chars) for _ in range(16))

def totp_code(secret_b32, t=None):
    if t is None: t = time.time()
    counter = int(t // 30)
    key = base64.b32decode(secret_b32, casefold=True)
    msg = counter.to_bytes(8, "big")
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = int.from_bytes(h[offset:offset+4], "big") & 0x7FFFFFFF
    return f"{code % 1000000:06d}"

def verify_totp(secret_b32, code_str):
    code_str = str(code_str).strip()
    if len(code_str) != 6 or not code_str.isdigit():
        return False
    now = time.time()
    for delta in (-30, 0, 30):
        try:
            if totp_code(secret_b32, now + delta) == code_str:
                return True
        except Exception:
            pass
    return False

# ---------- SP-Test (Speed Test 100MB) ----------
def run_speed_test(cid):
    with lock:
        c = db_conn.execute("SELECT id, name, port FROM configs WHERE id=?", (cid,)).fetchone()
    if not c:
        return {"error": "config not found"}
    port = c["port"]
    url = "https://speed.cloudflare.com/__down?bytes=104857600"
    cmd = [
        "curl", "-sS", "-o", "/dev/null",
        "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "-H", "Referer: https://speed.cloudflare.com/",
        "-H", "Origin: https://speed.cloudflare.com",
        "-w", "%{http_code} %{speed_download} %{time_total} %{size_download}",
        "--max-time", "25",
        "-x", f"socks5h://127.0.0.1:{port}",
        url
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        parts = r.stdout.strip().split()
        if len(parts) >= 4 and parts[0] == "200":
            bps = float(parts[1])
            mbps = round((bps * 8) / 1000000, 1)
            now = int(time.time())
            with lock:
                db_conn.execute("UPDATE configs SET last_speed_mbps=?, last_speed_time=? WHERE id=?", (mbps, now, cid))
                db_conn.commit()
            return {"ok": True, "mbps": mbps, "time": now, "elapsed": round(float(parts[2]), 2)}
        err = r.stderr.strip() or f"HTTP {parts[0] if parts else 'fail'}"
        return {"ok": False, "error": err[:150]}
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:150]}

sp_testing_all = False

def run_speed_test_all_worker():
    global sp_testing_all
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT c.id FROM configs c
            JOIN (SELECT config_id, ok, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
            WHERE c.enabled=1 AND ch.ok=1
        """).fetchall()]
    for r in rows:
        run_speed_test(r["id"])
        time.sleep(1)
    sp_testing_all = False

def send_telegram_doc(filepath, caption=""):
    s = get_settings()
    tok, chat = s.get("token", ""), s.get("chat", "")
    if not tok or not chat or not os.path.exists(filepath):
        return False
    with lock:
        ports = [r["port"] for r in db_conn.execute("""
            SELECT c.port FROM configs c
            JOIN checks ch ON ch.config_id = c.id
            WHERE c.enabled=1 AND ch.ok=1
            GROUP BY c.id ORDER BY MAX(ch.checked_at) DESC LIMIT 5
        """).fetchall()]
    for p in ports:
        cmd = ["curl", "-sS", "--max-time", "40", "-x", f"socks5h://127.0.0.1:{p}",
               "-F", f"chat_id={chat}",
               "-F", f"caption={caption}",
               "-F", f"document=@{filepath}",
               f"https://api.telegram.org/bot{tok}/sendDocument"]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
            if '"ok":true' in r.stdout:
                return True
        except Exception:
            pass
    cmd_dir = ["curl", "-sS", "--max-time", "40",
               "-F", f"chat_id={chat}",
               "-F", f"caption={caption}",
               "-F", f"document=@{filepath}",
               f"https://api.telegram.org/bot{tok}/sendDocument"]
    try:
        r = subprocess.run(cmd_dir, capture_output=True, text=True, timeout=45)
        if '"ok":true' in r.stdout:
            return True
    except Exception:
        pass
    return False

MAIN_KEYBOARD = {
    "inline_keyboard": [
        [
            {"text": "📊 وضعیت شبکه", "callback_data": "/status"},
            {"text": "🔄 تست سلامت فوری", "callback_data": "/check"}
        ],
        [
            {"text": "🔴 لیست قطعی‌ها", "callback_data": "/down"},
            {"text": "⚡ ۵ نود پرسرعت", "callback_data": "/top"}
        ],
        [
            {"text": "📡 لینک سابسکریپشن", "callback_data": "/sub"},
            {"text": "📦 دریافت بک‌آپ", "callback_data": "/backup"}
        ]
    ]
}

def answer_callback_query(tok, cb_id, ports=None):
    if not tok or not cb_id:
        return
    url = f"https://api.telegram.org/bot{tok}/answerCallbackQuery?callback_query_id={cb_id}"
    if ports:
        for p in ports:
            try:
                subprocess.run(["curl", "-sS", "--max-time", "5", "-x", f"socks5h://127.0.0.1:{p}", url], capture_output=True, timeout=6)
                return
            except Exception:
                pass
    try:
        subprocess.run(["curl", "-sS", "--max-time", "5", url], capture_output=True, timeout=6)
    except Exception:
        pass

def handle_bot_command(cmd_text, chat_id):
    cmd = cmd_text.strip().split()[0].lower().split("@")[0]
    s = get_settings()
    if cmd in ("/start", "/help"):
        return (
            "🛡️ <b>ربات مدیریت و مانیتورینگ Sentinel</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━\n"
            "<b>دستورات قابل استفاده:</b>\n"
            "• <b>/status</b> — گزارش جامع سلامت و پینگ نودها\n"
            "• <b>/top</b> — معرفی ۵ نود برتر با کمترین تاخیر\n"
            "• <b>/down</b> — لیست نودهای دارای قطعی و مدت زمان\n"
            "• <b>/check</b> یا <b>/ping</b> — تریگر فوری تست سلامت\n"
            "• <b>/sub</b> — دریافت لینک تمیز و سالم VLESS\n"
            "• <b>/backup</b> — دانلود مستقیم دیتابیس در چت\n"
            "━━━━━━━━━━━━━━━━━━━━━\n"
            "<i>جهت دسترسی سریع می‌توانید از کلیدهای شیشه‌ای زیر استفاده کنید:</i>",
            MAIN_KEYBOARD
        )
    if cmd == "/status":
        with lock:
            total = db_conn.execute("SELECT COUNT(*) AS c FROM configs").fetchone()["c"]
            up = db_conn.execute("""SELECT COUNT(DISTINCT c.id) AS c FROM configs c
                JOIN (SELECT config_id, ok, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
                WHERE c.enabled=1 AND ch.ok=1""").fetchone()["c"]
            down = db_conn.execute("SELECT COUNT(*) AS c FROM incidents WHERE resolved_at IS NULL").fetchone()["c"]
            avg_lat = db_conn.execute("""SELECT ROUND(AVG(latency_ms)) AS a FROM checks
                WHERE ok=1 AND checked_at >= ?""", (int(time.time()) - 3600,)).fetchone()["a"]
            iran_only = db_conn.execute("""SELECT COUNT(DISTINCT c.id) AS c FROM configs c
                JOIN (SELECT config_id, ok, ok_iran, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
                WHERE c.enabled=1 AND ch.ok=0 AND ch.ok_iran=1""").fetchone()["c"]
        lat_txt = f"{int(avg_lat)}ms" if avg_lat else "N/A"
        nat_txt = f"\n🟡 <b>اینترنت ملی:</b> {iran_only} نود در وضعیت اینترانت" if iran_only else ""
        return (
            f"📊 <b>گزارش جامع وضعیت شبکه | Status Report</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🟢 <b>نودهای فعال و سالم:</b> <b>{up}</b>\n"
            f"🔴 <b>نودهای دارای قطعی:</b> <b>{down}</b>\n"
            f"⚪ <b>مجموع کل نودها:</b> <b>{total}</b>\n"
            f"⚡ <b>میانگین پینگ (۱ ساعت اخیر):</b> <b>{lat_txt}</b>"
            f"{nat_txt}\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>پایش خودکار و پایدار روی تمامی سرورها فعال است.</i>",
            MAIN_KEYBOARD
        )
    if cmd == "/top":
        with lock:
            rows = db_conn.execute("""
                SELECT c.name, c.addr, ch.latency_ms FROM configs c
                JOIN (SELECT config_id, ok, latency_ms, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
                WHERE c.enabled=1 AND ch.ok=1
                ORDER BY ch.latency_ms ASC LIMIT 5
            """).fetchall()
        if not rows:
            return "⚠️ هیچ نود فعالی با تست موفق یافت نشد.", MAIN_KEYBOARD
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]
        lines = ["⚡ <b>۵ نود برتر شبکه (کمترین پینگ)</b>\n━━━━━━━━━━━━━━━━━━━━━"]
        for idx, r in enumerate(rows):
            m = medals[idx] if idx < len(medals) else "•"
            lines.append(f"{m} <b>{r['name']}</b>\n   🌐 <code>{r['addr']}</code> — ⚡ <b>{r['latency_ms']}ms</b>")
        lines.append("━━━━━━━━━━━━━━━━━━━━━\n<i>نودهای فوق بالاترین سرعت و بهترین کیفیت اتصال را دارند.</i>")
        return "\n".join(lines), MAIN_KEYBOARD
    if cmd in ("/check", "/ping"):
        wake.set()
        return (
            "🔄 <b>درخواست تست فوری ثبت شد!</b>\n"
            "الگوریتم پایش دوره‌ای برای تمامی کانفیگ‌ها فعال گردید.",
            MAIN_KEYBOARD
        )
    if cmd == "/down":
        with lock:
            rows = db_conn.execute("""
                SELECT c.name, c.addr, i.started_at, i.last_error FROM incidents i
                JOIN configs c ON c.id=i.config_id WHERE i.resolved_at IS NULL
            """).fetchall()
        if not rows:
            return ("✅ <b>تمامی نودها در وضعیت پایدار و متصل هستند!</b>\nهیچ قطعی فعالی در شبکه وجود ندارد.", MAIN_KEYBOARD)
        lines = ["🔴 <b>لیست قطعی‌های فعال | Active Outages</b>\n━━━━━━━━━━━━━━━━━━━━━\n"]
        for r in rows:
            dur = format_dur(int(time.time()) - r["started_at"])
            lines.append(f"• <b>{r['name']}</b> (<code>{r['addr']}</code>)\n   ⏱ <b>مدت قطعی:</b> {dur}\n   ⚠️ <b>خطا:</b> <code>{r['last_error']}</code>\n")
        lines.append("━━━━━━━━━━━━━━━━━━━━━\n<i>نودهای فوق از لیست سابسکریپشن کاربران حذف شده‌اند.</i>")
        return "\n".join(lines), MAIN_KEYBOARD
    if cmd == "/sub":
        tok = get_meta("sub_token")
        port = get_meta("port")
        with lock:
            cnt = db_conn.execute("""SELECT COUNT(DISTINCT c.id) AS c FROM configs c
                JOIN (SELECT config_id, ok, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
                WHERE c.enabled=1 AND ch.ok=1 AND c.id NOT IN (SELECT config_id FROM incidents WHERE resolved_at IS NULL)""").fetchone()["c"]
        host = get_public_ip()
        url = f"http://{host}:{port}/sub/{tok}"
        return (
            f"📡 <b>لینک سابسکریپشن پاک (Clean VLESS Feed)</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🟢 <b>نودهای سالم و فعال:</b> <b>{cnt}</b>\n\n"
            f"<code>{url}</code>\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>نودهای قطع شده به صورت خودکار از این لینک فیلتر می‌شوند.</i>",
            MAIN_KEYBOARD
        )
    if cmd == "/backup":
        db_path = D + "/sentinel.db"
        now_str = time.strftime("%Y-%m-%d %H:%M UTC")
        threading.Thread(target=send_telegram_doc, args=(db_path, f"Sentinel Database Backup ({now_str})"), daemon=True).start()
        return ("📦 <b>درخواست بک‌آپ ثبت شد!</b> فایل پشتیبان دیتابیس ارسال خواهد شد.", MAIN_KEYBOARD)
    return None

last_backup_day = None

def telegram_bot_worker():
    global last_backup_day
    offset = 0
    while True:
        try:
            s = get_settings()
            tok = s.get("token", "")
            target_chat = s.get("chat", "").strip()
            if not tok:
                time.sleep(10)
                continue

            # Daily backup at 00:00 UTC
            now_day = time.strftime("%Y-%m-%d", time.gmtime())
            now_hour = time.strftime("%H", time.gmtime())
            if now_hour == "00" and last_backup_day != now_day and target_chat:
                last_backup_day = now_day
                db_path = D + "/sentinel.db"
                send_telegram_doc(db_path, f"Automated Daily Backup ({now_day} 00:00 UTC)")

            # Query updates through healthy socks proxy
            with lock:
                ports = [r["port"] for r in db_conn.execute("""
                    SELECT c.port FROM configs c
                    JOIN checks ch ON ch.config_id = c.id
                    WHERE c.enabled=1 AND ch.ok=1
                    GROUP BY c.id ORDER BY MAX(ch.checked_at) DESC LIMIT 3
                """).fetchall()]

            data = None
            for p in ports:
                url = f"https://api.telegram.org/bot{tok}/getUpdates?offset={offset}&timeout=20"
                cmd = ["curl", "-sS", "--max-time", "25", "-x", f"socks5h://127.0.0.1:{p}", url]
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                    res = json.loads(r.stdout)
                    if res.get("ok"):
                        data = res.get("result", [])
                        break
                except Exception:
                    pass

            if not data and not ports:
                url = f"https://api.telegram.org/bot{tok}/getUpdates?offset={offset}&timeout=10"
                try:
                    r = subprocess.run(["curl", "-sS", "--max-time", "15", url], capture_output=True, text=True, timeout=18)
                    res = json.loads(r.stdout)
                    if res.get("ok"):
                        data = res.get("result", [])
                except Exception:
                    pass

            if data:
                for item in data:
                    offset = item["update_id"] + 1
                    msg = item.get("message")
                    cb = item.get("callback_query")
                    if cb:
                        cb_id = cb.get("id")
                        cb_data = cb.get("data", "")
                        cb_chat = str(cb.get("message", {}).get("chat", {}).get("id", ""))
                        if not target_chat or cb_chat == target_chat or f"-100{cb_chat}" == target_chat:
                            answer_callback_query(tok, cb_id, ports)
                            reply = handle_bot_command(cb_data, cb_chat)
                            if reply:
                                if isinstance(reply, tuple):
                                    send_telegram(reply[0], reply_markup=reply[1])
                                else:
                                    send_telegram(reply)
                    elif msg:
                        text = msg.get("text", "")
                        sender_chat = str(msg.get("chat", {}).get("id", ""))
                        if not text or not sender_chat:
                            continue
                        # Security: only reply if chat matches configured chat
                        if target_chat and sender_chat != target_chat and f"-100{sender_chat}" != target_chat:
                            continue
                        reply = handle_bot_command(text, sender_chat)
                        if reply:
                            if isinstance(reply, tuple):
                                send_telegram(reply[0], reply_markup=reply[1])
                            else:
                                send_telegram(reply)
            else:
                time.sleep(3)
        except Exception as e:
            time.sleep(5)

def flush_alerts():
    with lock:
        cur = db_conn.execute("SELECT id, text FROM pending_alerts ORDER BY id ASC LIMIT 10")
        rows = cur.fetchall()
        for r in rows:
            if send_telegram(r["text"]):
                db_conn.execute("DELETE FROM pending_alerts WHERE id=?", (r["id"],))
                db_conn.commit()
            else:
                break

def format_dur(sec):
    s = int(sec)
    if s < 60: return f"{s}s"
    if s < 3600: return f"{s//60}m {s%60}s"
    return f"{s//3600}h {(s%3600)//60}m"

def tick():
    s = get_settings()
    threshold = int(s.get("threshold", 3))
    timeout = int(s.get("timeout", 8))
    probe_url = s.get("url", "http://cp.cloudflare.com/generate_204")

    with lock:
        cur = db_conn.execute("""
            SELECT c.id, c.name, c.uri, c.addr, c.port, c.sub_id, s.name as sub_name, s.url as sub_url
            FROM configs c
            LEFT JOIN subscriptions s ON s.id = c.sub_id
            WHERE c.enabled=1
        """)
        configs = [dict(r) for r in cur.fetchall()]

    if not configs:
        flush_alerts()
        return

    # Randomize test order to prevent synchronized bursts or hotspotting
    random.shuffle(configs)

    # Staggered testing one-by-one with 500ms pacing pause
    for idx, cfg in enumerate(configs):
        cid, ok, ms, err, ok_iran = probe_one(cfg, timeout, probe_url)
        now = int(time.time())

        with lock:
            db_conn.execute(
                "INSERT INTO checks (config_id, ok, latency_ms, error, checked_at, ok_iran) VALUES (?, ?, ?, ?, ?, ?)",
                (cid, 1 if ok else 0, ms, err, now, ok_iran)
            )
            sub_info = f"<b>{cfg['sub_name']}</b>" if cfg.get("sub_name") else "<i>دستی (Manual)</i>"
            time_str = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(now))

            cur = db_conn.execute("SELECT * FROM incidents WHERE config_id=? AND resolved_at IS NULL ORDER BY id DESC LIMIT 1", (cid,))
            inc = cur.fetchone()
            if ok:
                if inc:
                    db_conn.execute("UPDATE incidents SET resolved_at=?, resolved_alert_sent=1 WHERE id=?", (now, inc["id"]))
                    dur = format_dur(now - inc["started_at"])
                    msg = (
                        f"🟢 <b>اتصال مجدد نود | Node Restored</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n"
                        f"📡 <b>نام نود:</b> <code>{cfg['name']}</code>\n"
                        f"🌐 <b>آدرس:</b> <code>{cfg['addr']}</code>\n"
                        f"📦 <b>اشتراک:</b> {sub_info}\n"
                        f"⏱ <b>مدت زمان قطعی:</b> <b>{dur}</b>\n"
                        f"⚡ <b>تاخیر پینگ:</b> <b>{ms}ms</b>\n"
                        f"🕒 <b>زمان بازگشت:</b> <code>{time_str}</code>\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n"
                        f"<i>نود مجدداً به لینک سابسکریپشن کاربران اضافه شد.</i>"
                    )
                    db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))
            else:
                cur = db_conn.execute("SELECT ok FROM checks WHERE config_id=? ORDER BY id DESC LIMIT ?", (cid, threshold))
                recent = [r["ok"] for r in cur.fetchall()]
                if len(recent) >= threshold and all(v == 0 for v in recent):
                    if not inc:
                        db_conn.execute(
                            "INSERT INTO incidents (config_id, started_at, last_error, alert_sent, last_reminder_at) VALUES (?, ?, ?, 1, ?)",
                            (cid, now, err, now)
                        )
                        net_tag = "\n🟡 <b>وضعیت: اینترنت ملی (Intranet Only)</b>\n" if ok_iran == 1 else ""
                        msg = (
                            f"🔴 <b>هشدار قطعی نود | Node Outage Alert</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"📡 <b>نام نود:</b> <code>{cfg['name']}</code>\n"
                            f"🌐 <b>آدرس:</b> <code>{cfg['addr']}</code>\n"
                            f"📦 <b>اشتراک:</b> {sub_info}\n"
                            f"❌ <b>تعداد تست ناموفق:</b> {threshold}\n"
                            f"⚠️ <b>علت خطا:</b> <code>{err}</code>"
                            f"{net_tag}\n"
                            f"🕒 <b>زمان رخداد:</b> <code>{time_str}</code>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"<i>نود موقتاً از لینک سابسکریپشن کاربران حذف شد.</i>"
                        )
                        db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))
                    else:
                        db_conn.execute("UPDATE incidents SET last_error=? WHERE id=?", (err, inc["id"]))
                        inc_dict = dict(inc)
                        last_rem = inc_dict.get("last_reminder_at") or inc_dict.get("started_at") or now
                        if (now - last_rem) >= 7200:
                            db_conn.execute("UPDATE incidents SET last_reminder_at=? WHERE id=?", (now, inc["id"]))
                            dur = format_dur(now - inc_dict["started_at"])
                            msg = (
                                f"⏳ <b>یادآوری: قطعی ادامه‌دار | Ongoing Outage</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━\n"
                                f"📡 <b>نام نود:</b> <code>{cfg['name']}</code>\n"
                                f"🌐 <b>آدرس:</b> <code>{cfg['addr']}</code>\n"
                                f"📦 <b>اشتراک:</b> {sub_info}\n"
                                f"⌛ <b>مدت کل قطعی:</b> <b>{dur}</b>\n"
                                f"⚠️ <b>آخرین خطا:</b> <code>{err}</code>\n"
                                f"🕒 <b>زمان پایش:</b> <code>{time_str}</code>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━\n"
                                f"<i>این نود همچنان قطع است و از سابسکریپشن کاربران خارج می‌باشد.</i>"
                            )
                            db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))

            db_conn.commit()

        if idx < len(configs) - 1:
            time.sleep(0.5)

    with lock:
        cutoff = int(time.time()) - (30 * 86400)
        db_conn.execute("DELETE FROM checks WHERE checked_at < ?", (cutoff,))
        db_conn.commit()

    flush_alerts()

# ---------- Subscriptions ----------
def _curl_text(url, proxy_port=None, timeout=20):
    cmd = ["curl", "-sSL", "--max-time", str(timeout), "--max-filesize", "5000000",
           "-A", "v2rayN/6.0", "-w", "\n%{http_code}"]
    if proxy_port:
        cmd += ["-x", f"socks5h://127.0.0.1:{proxy_port}"]
    r = subprocess.run(cmd + [url], capture_output=True, text=True, timeout=timeout + 5)
    body, _, code = r.stdout.rpartition("\n")
    if r.returncode != 0 or not code.startswith("2"):
        raise RuntimeError((r.stderr.strip() or f"HTTP {code or 'none'}")[:120])
    return body

def decode_sub(text):
    """Subscription body: plain proxy URIs (vless/trojan/ss/vmess), or (urlsafe) base64 of them."""
    t = text.strip()
    schemes = ("vless://", "trojan://", "ss://", "vmess://")
    if not any(s in t for s in schemes):
        try:
            raw = re.sub(r"\s+", "", t)
            t = base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8", "replace")
        except Exception:
            raise ValueError("Not a base64/plain subscription")
    uris, seen = [], set()
    for line in t.splitlines():
        line = line.strip()
        if any(line.startswith(s) for s in schemes) and line not in seen:
            seen.add(line); uris.append(line)
    if not uris:
        raise ValueError("No valid proxy links (vless/trojan/ss/vmess) found in subscription")
    return uris

def fetch_sub(url):
    if not re.fullmatch(r"https?://[^\s\"']+", url):
        raise ValueError("Subscription URL must start with http:// or https://")
    errs = []
    try:
        return decode_sub(_curl_text(url))
    except Exception as e:
        errs.append(f"direct: {e}")
    with lock:
        ports = [r["port"] for r in db_conn.execute("""SELECT c.port FROM configs c JOIN checks ch ON ch.config_id=c.id
            WHERE c.enabled=1 AND ch.ok=1 GROUP BY c.id ORDER BY MAX(ch.checked_at) DESC LIMIT 3""").fetchall()]
    for p in ports:
        try:
            return decode_sub(_curl_text(url, p))
        except Exception as e:
            errs.append(f"via :{p}: {e}")
    raise RuntimeError("; ".join(errs)[:300])

def sync_sub(sid):
    """Fetch a subscription and make its configs match exactly (strict prune)."""
    with lock:
        sub = db_conn.execute("SELECT * FROM subscriptions WHERE id=?", (sid,)).fetchone()
    if not sub:
        return {"error": "not found"}
    now = int(time.time())
    try:
        uris = fetch_sub(sub["url"])
    except Exception as e:
        with lock:
            db_conn.execute("UPDATE subscriptions SET last_sync=?, last_ok=0, last_msg=? WHERE id=?", (now, str(e)[:300], sid))
            db_conn.commit()
        return {"ok": False, "error": str(e)}
    added = removed = skipped = 0
    with lock:
        existing = {r["uri"]: r["id"] for r in db_conn.execute("SELECT id, uri FROM configs WHERE sub_id=?", (sid,))}
        others = {r["uri"] for r in db_conn.execute("SELECT uri FROM configs WHERE sub_id IS NULL OR sub_id != ?", (sid,))}
        next_port = db_conn.execute("SELECT COALESCE(MAX(port), ?) AS m FROM configs", (BASE_PORT,)).fetchone()["m"] + 1
        for uri in uris:
            if uri in existing:
                continue
            if uri in others:          # already added manually or by another sub: leave it alone
                skipped += 1
                continue
            try:
                info = parse_proxy_uri(uri)
                cid = secrets.token_hex(4)
                c = {"id": cid, "uri": uri}
                outbound_for(c)
                cc, cn = resolve_country(info["host"], info["name"])
                db_conn.execute(
                    "INSERT INTO configs (id, name, uri, addr, port, protocol, network, security, created_at, sub_id, country_code, country_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (cid, info["name"], uri, info["addr"], next_port, info["protocol"], info.get("network", "tcp"), info.get("security", "none"), now, sid, cc, cn))
                next_port += 1; added += 1
            except Exception:
                skipped += 1
        gone = [cid for uri, cid in existing.items() if uri not in set(uris)]
        for cid in gone:
            for t, col in (("configs", "id"), ("checks", "config_id"), ("incidents", "config_id")):
                db_conn.execute(f"DELETE FROM {t} WHERE {col}=?", (cid,))
            removed += 1
        total = db_conn.execute("SELECT COUNT(*) AS n FROM configs WHERE sub_id=?", (sid,)).fetchone()["n"]
        msg = f"+{added} new, -{removed} removed" + (f", {skipped} skipped" if skipped else "")
        db_conn.execute("UPDATE subscriptions SET last_sync=?, last_ok=1, last_msg=?, config_count=? WHERE id=?", (now, msg, total, sid))
        db_conn.commit()
    if added or removed:
        restart_xray()
        wake.set()
    return {"ok": True, "added": added, "removed": removed, "skipped": skipped, "total": total}

def sync_due_subs():
    now = int(time.time())
    with lock:
        due = [r["id"] for r in db_conn.execute(
            "SELECT id FROM subscriptions WHERE enabled=1 AND (last_sync IS NULL OR ? - last_sync >= interval_hours*3600)", (now,))]
    for sid in due:
        try:
            sync_sub(sid)
        except Exception as e:
            print("sub sync error:", e, flush=True)

def worker_loop():
    while True:
        try:
            with lock:
                has_cfgs = db_conn.execute("SELECT COUNT(*) AS c FROM configs WHERE enabled=1").fetchone()["c"] > 0
            if has_cfgs and (xp is None or xp.poll() is not None):
                restart_xray()
            sync_due_subs()
            tick()
        except Exception as e:
            print("worker error:", e, flush=True)
        s = get_settings()
        interval = max(2, int(s.get("interval", 30)))
        wake.wait(interval)
        wake.clear()

# ---------- HTTP Handler ----------
def sign_sid(exp):
    secret = get_meta("secret")
    return hmac.new(bytes.fromhex(secret), str(exp).encode(), hashlib.sha256).hexdigest()

class SentinelHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def out(self, code=200, body=b"", ct="application/json", cookie=None):
        if not isinstance(body, (bytes, str)):
            body = json.dumps(body)
        if isinstance(body, str):
            body = body.encode()
        gz = len(body) > 512 and "gzip" in self.headers.get("Accept-Encoding", "") and not ct.startswith(("image/", "font/"))
        if gz:
            body = gzip.compress(body, 6)
        self.send_response(code)
        if gz:
            self.send_header("Content-Encoding", "gzip")
        for k, v in [
            ("Content-Type", ct),
            ("Content-Length", len(body)),
            ("Cache-Control", "no-store"),
            ("X-Frame-Options", "DENY"),
            ("X-Content-Type-Options", "nosniff"),
            ("Referrer-Policy", "no-referrer")
        ]:
            self.send_header(k, v)
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def is_authed(self):
        try:
            cookie_hdr = self.headers.get("Cookie", "")
            exp_str, sig = SimpleCookie(cookie_hdr)["sid"].value.split(".")
            exp = int(exp_str)
            return exp > time.time() and hmac.compare_digest(sig, sign_sid(exp))
        except Exception:
            return False

    def do_GET(self): self.dispatch("GET")
    def do_POST(self): self.dispatch("POST")

    def dispatch(self, method):
        P = "/" + get_meta("path")
        path = self.path.split("?")[0]
        qs = up.parse_qs(up.urlparse(self.path).query)

        # Clean subscription feed (public with token)
        sub_tok = None
        if method == "GET":
            if path.startswith("/sub/"):
                sub_tok = path[5:].strip("/")
            elif path.startswith(P + "/sub/"):
                sub_tok = path[len(P) + 5:].strip("/")
        if sub_tok:
            valid_tok = get_meta("sub_token")
            if not valid_tok or not hmac.compare_digest(sub_tok, valid_tok):
                return self.out(404, "Invalid subscription token", "text/plain")

            sort_by = qs.get("sort", ["recent"])[0].lower()
            proto_filter = [p.strip().lower() for p in qs.get("proto", [""])[0].split(",") if p.strip()]
            country_filter = [c.strip().upper() for c in qs.get("country", [""])[0].split(",") if c.strip()]
            limit_val = None
            if "limit" in qs:
                try: limit_val = int(qs["limit"][0])
                except ValueError: pass

            where_clauses = [
                "c.enabled = 1",
                "ch.ok = 1",
                "c.id NOT IN (SELECT config_id FROM incidents WHERE resolved_at IS NULL)"
            ]
            params = []

            if proto_filter:
                placeholders = ",".join("?" * len(proto_filter))
                where_clauses.append(f"LOWER(c.protocol) IN ({placeholders})")
                params.extend(proto_filter)

            if country_filter:
                placeholders = ",".join("?" * len(country_filter))
                where_clauses.append(f"UPPER(c.country_code) IN ({placeholders})")
                params.extend(country_filter)

            if sort_by == "ping":
                order_clause = "ORDER BY ch.latency_ms ASC, c.created_at DESC"
            elif sort_by == "speed":
                order_clause = "ORDER BY c.last_speed_mbps DESC, c.created_at DESC"
            else:
                order_clause = "ORDER BY c.created_at DESC"

            limit_clause = f"LIMIT {int(limit_val)}" if limit_val and limit_val > 0 else ""

            where_str = " AND ".join(where_clauses)
            sql = f"""
                SELECT c.uri, c.name, c.protocol, c.country_code FROM configs c
                JOIN (SELECT config_id, ok, latency_ms, MAX(checked_at) AS max_t FROM checks GROUP BY config_id) ch ON ch.config_id = c.id
                WHERE {where_str}
                {order_clause}
                {limit_clause}
            """

            with lock:
                rows = db_conn.execute(sql, params).fetchall()
                uris = [r["uri"] for r in rows]

            raw_text = "\n".join(uris)
            fmt = qs.get("format", ["b64"])[0].lower()
            if fmt == "plain":
                out_body = raw_text.encode("utf-8")
            else:
                b64_feed = base64.b64encode(raw_text.encode("utf-8")).decode("ascii")
                out_body = b64_feed.encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(out_body)))
            self.send_header("Content-Disposition", 'attachment; filename="sentinel.txt"')
            self.send_header("Subscription-Userinfo", f"upload=0; download=0; total={len(uris)*1073741824}; expire=0")
            self.send_header("Profile-Update-Interval", "1")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.end_headers()
            self.wfile.write(out_body)
            return

        # Static assets
        if method == "GET" and path.startswith(P + "/static/"):
            rel = path[len(P) + 8:].strip("/")
            # protect directory traversal
            full = os.path.normpath(os.path.join(STATIC_DIR, rel))
            if full.startswith(STATIC_DIR) and os.path.isfile(full):
                ct = "text/plain"
                if full.endswith(".css"): ct = "text/css; charset=utf-8"
                elif full.endswith(".js"): ct = "application/javascript; charset=utf-8"
                elif full.endswith(".woff2"): ct = "font/woff2"
                elif full.endswith(".png"): ct = "image/png"
                elif full.endswith(".svg"): ct = "image/svg+xml"
                return self.out(200, open(full, "rb").read(), ct)
            return self.out(404)

        # Single page app entry
        if method == "GET" and path.rstrip("/") == P:
            return self.out(200, open(INDEX_FILE, "rb").read(), "text/html; charset=utf-8")

        # API routing
        if not path.startswith(P + "/api/"):
            return self.out(404)
        ep = path[len(P) + 5:]

        # CSRF check
        if self.headers.get("X-R") != "1":
            return self.out(403, {"error": "forbidden"})

        # Read JSON body for POST
        b = {}
        if method == "POST":
            clen = int(self.headers.get("Content-Length", 0))
            if clen > 500000:
                return self.out(413, {"error": "payload too large"})
            raw = self.rfile.read(clen) or b"{}"
            try:
                b = json.loads(raw.decode("utf-8"))
            except Exception:
                return self.out(400, {"error": "invalid json"})

        # External Alert from Hashem Panel (Localhost only)
        if ep == "external-alert":
            ip = self.client_address[0]
            if ip not in ("127.0.0.1", "::1", "localhost"):
                return self.out(403, {"error": "Localhost only"})
            txt = str(b.get("text", "")).strip()
            if not txt:
                return self.out(400, {"error": "text required"})
            threading.Thread(target=send_telegram, args=(txt,), daemon=True).start()
            return self.out(200, {"ok": True, "dispatched": True})

        # Public Login endpoint
        if ep == "login":
            ip = self.client_address[0]
            recent = [t for t in fails_by_ip.get(ip, []) if t > time.time() - 300]
            if len(recent) >= 5:
                return self.out(429, {"error": "too many attempts"})
            pw = str(b.get("password", ""))
            stored_pw = get_meta("pw")
            salt = get_meta("salt")
            if not hmac.compare_digest(hashpw(pw, salt), stored_pw):
                fails_by_ip[ip] = recent + [time.time()]
                time.sleep(1)
                return self.out(401, {"error": "invalid credentials"})

            # Check 2FA TOTP
            totp_on = get_meta("totp_enabled") == "1"
            if totp_on:
                code = str(b.get("totp_code", "")).strip()
                if not code:
                    return self.out(401, {"error": "2fa_required", "need_2fa": True})
                sec = get_meta("totp_secret") or ""
                if not verify_totp(sec, code):
                    time.sleep(1)
                    return self.out(401, {"error": "Invalid 2FA authenticator code", "need_2fa": True})

            exp = int(time.time()) + (86400 * 7)
            sig = sign_sid(exp)
            cookie = f"sid={exp}.{sig}; Path={P}; HttpOnly; SameSite=Strict; Max-Age=604800"
            return self.out(200, {"ok": True}, cookie=cookie)

        # All subsequent endpoints require auth
        if not self.is_authed():
            return self.out(401, {"error": "unauthorized"})

        if ep == "logout":
            cookie = f"sid=0; Path={P}; HttpOnly; Max-Age=0"
            return self.out(200, {"ok": True}, cookie=cookie)

        # Dashboard Summary
        if ep == "dashboard":
            with lock:
                cur = db_conn.execute("""
                    SELECT c.id, c.name, c.uri, c.addr, c.port, c.protocol, c.network, c.security, c.enabled, c.created_at, c.sub_id, c.last_speed_mbps, c.last_speed_time, c.country_code, c.country_name, s.name as sub_name, s.url as sub_url
                    FROM configs c
                    LEFT JOIN subscriptions s ON s.id = c.sub_id
                    ORDER BY c.created_at DESC
                """)
                cfgs = [dict(r) for r in cur.fetchall()]
                # latest check per config
                cur = db_conn.execute("""
                    SELECT c1.config_id, c1.ok, c1.latency_ms, c1.error, c1.checked_at, c1.ok_iran
                    FROM checks c1
                    JOIN (SELECT config_id, MAX(id) AS max_id FROM checks GROUP BY config_id) c2
                    ON c1.id = c2.max_id
                """)
                latest = {r["config_id"]: dict(r) for r in cur.fetchall()}
                # open incidents
                cur = db_conn.execute("SELECT config_id, started_at, last_error FROM incidents WHERE resolved_at IS NULL")
                down_cfgs = {r["config_id"]: dict(r) for r in cur.fetchall()}

                cur = db_conn.execute("SELECT config_id, COUNT(*) AS n, SUM(ok) AS up FROM checks WHERE checked_at>=? GROUP BY config_id", (int(time.time()) - 86400,))
                upt = {r["config_id"]: (round(100.0 * r["up"] / r["n"], 1) if r["n"] else None) for r in cur.fetchall()}
                since_24h = int(time.time()) - 24 * 3600
                cur_sla = db_conn.execute(
                    "SELECT config_id, checked_at, ok, latency_ms FROM checks WHERE checked_at >= ? ORDER BY checked_at ASC",
                    (since_24h,)
                )
                checks_by_cfg = {}
                for r_ch in cur_sla.fetchall():
                    checks_by_cfg.setdefault(r_ch["config_id"], []).append(r_ch)

                now_ts = int(time.time())
                start_24h = now_ts - 24 * 3600

                for c in cfgs:
                    c["uptime"] = upt.get(c["id"])
                    c["country_flag"] = country_flag(c.get("country_code"))
                    ch = latest.get(c["id"], {})
                    c["last_ok"] = ch.get("ok")
                    c["latency"] = ch.get("latency_ms")
                    c["ok_iran"] = ch.get("ok_iran", 1)
                    c["last_error"] = ch.get("error", "")
                    c["last_check"] = ch.get("checked_at")
                    c["is_down"] = c["id"] in down_cfgs
                    c["down_since"] = down_cfgs[c["id"]]["started_at"] if c["is_down"] else None

                    # Compute 24 hourly SLA bars
                    c_checks = checks_by_cfg.get(c["id"], [])
                    buckets = [[] for _ in range(24)]
                    for r_c in c_checks:
                        b_idx = int((r_c["checked_at"] - start_24h) // 3600)
                        if 0 <= b_idx < 24:
                            buckets[b_idx].append(r_c)
                    bars = []
                    for b_i in range(24):
                        slot_t = start_24h + b_i * 3600
                        slot_hr = time.strftime("%H:00", time.localtime(slot_t))
                        b_items = buckets[b_i]
                        if not b_items:
                            bars.append({"h": slot_hr, "status": -1, "up_pct": None, "ms": None})
                        else:
                            tot = len(b_items)
                            up_cnt = sum(1 for x in b_items if x["ok"])
                            lats = [x["latency_ms"] for x in b_items if x["ok"] and x["latency_ms"]]
                            avg_ms = round(sum(lats) / len(lats)) if lats else None
                            pct = round(100.0 * up_cnt / tot, 1)
                            st = 1 if up_cnt == tot else (0 if up_cnt == 0 else 2)
                            bars.append({"h": slot_hr, "status": st, "up_pct": pct, "ms": avg_ms})
                    c["sla_bars"] = bars

                # Recent incidents
                cur = db_conn.execute("""
                    SELECT i.id, i.started_at, i.resolved_at, i.last_error, c.name, c.addr
                    FROM incidents i
                    JOIN configs c ON c.id = i.config_id
                    ORDER BY i.started_at DESC LIMIT 10
                """)
                recent_inc = [dict(r) for r in cur.fetchall()]

                # Pending alerts count
                cur = db_conn.execute("SELECT COUNT(*) AS c FROM pending_alerts")
                pending = cur.fetchone()["c"]

                s = get_settings()
                s["token_configured"] = bool(s.get("token"))
                s.pop("token", None)

                return self.out(200, {
                    "configs": cfgs,
                    "incidents": recent_inc,
                    "settings": s,
                    "pending_alerts": pending
                })

        # Configs CRUD
        if ep == "configs":
            with lock:
                rows = [dict(r) for r in db_conn.execute("""
                    SELECT c.id, c.name, c.uri, c.addr, c.port, c.protocol, c.network, c.security, c.enabled, c.created_at, c.sub_id, s.name as sub_name, s.url as sub_url
                    FROM configs c
                    LEFT JOIN subscriptions s ON s.id = c.sub_id
                    ORDER BY c.created_at DESC
                """).fetchall()]
            return self.out(200, {"configs": rows})

        if ep == "configs/add":
            text = str(b.get("text", "")).strip()
            if not text:
                return self.out(400, {"error": "no URIs provided"})
            added, errs = 0, []
            with lock:
                cur = db_conn.execute("SELECT COALESCE(MAX(port), ?) AS maxp FROM configs", (BASE_PORT,))
                next_port = cur.fetchone()["maxp"] + 1
                for line in text.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        info = parse_proxy_uri(line)
                        cid = secrets.token_hex(4)
                        c = {
                            "id": cid, "name": info["name"], "uri": line, "addr": info["addr"],
                            "port": next_port, "protocol": info["protocol"], "network": info.get("network", "tcp"),
                            "security": info.get("security", "none"), "created_at": int(time.time())
                        }
                        outbound_for(c)
                        cc, cn = resolve_country(info["host"], info["name"])
                        db_conn.execute(
                            "INSERT OR IGNORE INTO configs (id, name, uri, addr, port, protocol, network, security, created_at, country_code, country_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            (c["id"], c["name"], c["uri"], c["addr"], c["port"], c["protocol"], c["network"], c["security"], c["created_at"], cc, cn)
                        )
                        next_port += 1
                        added += 1
                    except Exception as ex:
                        errs.append(f"{line[:30]}...: {str(ex)}")
                db_conn.commit()
            if added:
                restart_xray()
                wake.set()
            return self.out(200, {"added": added, "errors": errs})

        if ep == "configs/delete":
            cid = str(b.get("id", ""))
            with lock:
                db_conn.execute("DELETE FROM configs WHERE id=?", (cid,))
                db_conn.execute("DELETE FROM checks WHERE config_id=?", (cid,))
                db_conn.execute("DELETE FROM incidents WHERE config_id=?", (cid,))
                db_conn.commit()
            restart_xray()
            return self.out(200, {"ok": True})

        if ep == "configs/toggle":
            cid = str(b.get("id", ""))
            with lock:
                cur = db_conn.execute("SELECT enabled FROM configs WHERE id=?", (cid,))
                r = cur.fetchone()
                if not r:
                    return self.out(404, {"error": "not found"})
                new_state = 0 if r["enabled"] else 1
                db_conn.execute("UPDATE configs SET enabled=? WHERE id=?", (new_state, cid))
                db_conn.commit()
            restart_xray()
            wake.set()
            return self.out(200, {"ok": True, "enabled": new_state})

        # Per-config detail: stats + recent checks
        if ep == "config":
            cid = qs.get("id", [""])[0]
            span = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}.get(qs.get("range", ["24h"])[0], 86400)
            since = int(time.time()) - span
            with lock:
                r = db_conn.execute("SELECT * FROM configs WHERE id=?", (cid,)).fetchone()
                if not r:
                    return self.out(404, {"error": "not found"})
                st = db_conn.execute(
                    "SELECT COUNT(*) AS n, SUM(ok) AS up, AVG(CASE WHEN ok=1 THEN latency_ms END) AS avg, "
                    "MIN(CASE WHEN ok=1 THEN latency_ms END) AS mn, MAX(CASE WHEN ok=1 THEN latency_ms END) AS mx "
                    "FROM checks WHERE config_id=? AND checked_at>=?", (cid, since)).fetchone()
                pts = [dict(x) for x in db_conn.execute(
                    "SELECT checked_at, ok, latency_ms, error FROM checks WHERE config_id=? AND checked_at>=? ORDER BY checked_at ASC",
                    (cid, since)).fetchall()]
                incs = [dict(x) for x in db_conn.execute(
                    "SELECT id, started_at, resolved_at, last_error FROM incidents WHERE config_id=? ORDER BY started_at DESC LIMIT 20",
                    (cid,)).fetchall()]
            n = st["n"] or 0
            return self.out(200, {
                "config": dict(r), "points": pts, "incidents": incs, "span": span,
                "stats": {"checks": n, "uptime": round(100.0 * (st["up"] or 0) / n, 2) if n else None,
                          "avg": round(st["avg"]) if st["avg"] is not None else None, "min": st["mn"], "max": st["mx"]}})

        if ep == "configs/rename":
            cid, name = str(b.get("id", "")), str(b.get("name", "")).strip()[:80]
            if not name:
                return self.out(400, {"error": "name required"})
            with lock:
                db_conn.execute("UPDATE configs SET name=? WHERE id=?", (name, cid))
                db_conn.commit()
            return self.out(200, {"ok": True})

        if ep == "password":
            old, new = str(b.get("old", "")), str(b.get("new", ""))
            if len(new) < 8:
                return self.out(400, {"error": "New password must be at least 8 characters"})
            if not hmac.compare_digest(hashpw(old, get_meta("salt")), get_meta("pw")):
                return self.out(403, {"error": "Current password is wrong"})
            salt = secrets.token_hex(8)
            with lock:
                for k, v in (("salt", salt), ("pw", hashpw(new, salt))):
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (k, v))
                db_conn.commit()
            return self.out(200, {"ok": True})

        if ep == "incidents.csv":
            with lock:
                rows = db_conn.execute(
                    "SELECT c.name, c.addr, i.started_at, i.resolved_at, i.last_error FROM incidents i "
                    "JOIN configs c ON c.id=i.config_id ORDER BY i.started_at DESC").fetchall()
            def q(v): return '"' + str(v if v is not None else "").replace('"', '""') + '"'
            iso = lambda t: time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(t)) if t else ""
            out = "name,address,started_utc,resolved_utc,duration_s,error\n" + "".join(
                ",".join([q(r["name"]), q(r["addr"]), q(iso(r["started_at"])), q(iso(r["resolved_at"])),
                          q((r["resolved_at"] - r["started_at"]) if r["resolved_at"] else ""), q(r["last_error"])]) + "\n" for r in rows)
            return self.out(200, out, "text/csv; charset=utf-8")

        # SP-Test Endpoints
        if ep == "speedtest":
            cid = str(b.get("id", "")).strip()
            res = run_speed_test(cid)
            return self.out(200 if res.get("ok") else 400, res)

        if ep == "speedtest/all":
            global sp_testing_all
            if sp_testing_all:
                return self.out(409, {"error": "Speed test already in progress"})
            sp_testing_all = True
            threading.Thread(target=run_speed_test_all_worker, daemon=True).start()
            return self.out(200, {"ok": True, "message": "Speed test started across healthy nodes"})

        # Support / Donate Nudge
        if ep == "support":
            act = str(b.get("action", "claim"))
            now = int(time.time())
            with lock:
                snooze_until = int(get_meta("sup_snooze_until") or 0)
                last_shown = int(get_meta("sup_last_shown") or 0)

            if act == "claim":
                # Only show if not snoozed and not shown in last 3 days
                should_show = (now >= snooze_until) and (now - last_shown >= 3 * 86400)
                if should_show:
                    with lock:
                        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_last_shown', ?)", (str(now),))
                        db_conn.commit()
                return self.out(200, {"show": should_show})

            if act in ("close", "later"):
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            if act == "snooze":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 30 * 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            if act == "donate":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 90 * 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            return self.out(200, {"ok": True})

        # 2FA Management Endpoints
        if ep == "2fa":
            is_on = get_meta("totp_enabled") == "1"
            sec = get_meta("totp_secret") if is_on else generate_totp_secret()
            uri = f"otpauth://totp/Sentinel:admin?secret={sec}&issuer=Sentinel"
            return self.out(200, {"enabled": is_on, "secret": sec, "uri": uri})

        if ep == "2fa/enable":
            sec = str(b.get("secret", "")).strip()
            code = str(b.get("code", "")).strip()
            if not verify_totp(sec, code):
                return self.out(400, {"error": "Invalid 6-digit code. Please check your authenticator app."})
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_secret', ?)", (sec,))
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_enabled', '1')")
                db_conn.commit()
            return self.out(200, {"ok": True})

        if ep == "2fa/disable":
            pw = str(b.get("password", ""))
            stored_pw = get_meta("pw")
            salt = get_meta("salt")
            if not hmac.compare_digest(hashpw(pw, salt), stored_pw):
                return self.out(403, {"error": "Invalid admin password"})
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_enabled', '0')")
                db_conn.commit()
            return self.out(200, {"ok": True})

        # Clean Subscription Info & Rotate
        if ep == "clean-sub":
            tok = get_meta("sub_token")
            with lock:
                h_count = db_conn.execute("""
                    SELECT COUNT(*) AS c FROM configs c
                    JOIN (SELECT config_id, ok, MAX(checked_at) AS max_t FROM checks GROUP BY config_id) ch ON ch.config_id = c.id
                    WHERE c.enabled=1 AND ch.ok=1
                    AND c.id NOT IN (SELECT config_id FROM incidents WHERE resolved_at IS NULL)
                """).fetchone()["c"]
                tot_count = db_conn.execute("SELECT COUNT(*) AS c FROM configs").fetchone()["c"]
                protos = [r["protocol"] for r in db_conn.execute("SELECT DISTINCT protocol FROM configs WHERE enabled=1 AND protocol IS NOT NULL").fetchall()]
                countries = [dict(r) for r in db_conn.execute("SELECT DISTINCT country_code, country_name FROM configs WHERE enabled=1 AND country_code != '' AND country_code != 'XX'").fetchall()]
                for cc_item in countries:
                    cc_item["flag"] = country_flag(cc_item.get("country_code"))
            return self.out(200, {
                "token": tok,
                "url": f"/sub/{tok}",
                "healthy_count": h_count,
                "total_count": tot_count,
                "protocols": protos,
                "countries": countries
            })

        if ep == "clean-sub/rotate":
            new_tok = secrets.token_hex(8)
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sub_token', ?)", (new_tok,))
                db_conn.commit()
            return self.out(200, {"ok": True, "token": new_tok, "url": f"/sub/{new_tok}"})

        # Subscriptions
        if ep == "subscriptions":
            with lock:
                rows = [dict(r) for r in db_conn.execute("SELECT id, name, url, interval_hours, enabled, last_sync, last_ok, last_msg, config_count, created_at FROM subscriptions ORDER BY created_at DESC")]
            return self.out(200, {"subscriptions": rows})

        if ep == "subscriptions/add":
            url, name = str(b.get("url", "")).strip(), str(b.get("name", "")).strip()[:60]
            hrs = int(b.get("interval_hours", 6))
            if hrs not in (1, 6, 12, 24):
                return self.out(400, {"error": "Interval must be 1, 6, 12 or 24 hours"})
            if not re.fullmatch(r"https?://[^\s\"']+", url):
                return self.out(400, {"error": "URL must start with http:// or https://"})
            sid = secrets.token_hex(4)
            with lock:
                if db_conn.execute("SELECT 1 FROM subscriptions WHERE url=?", (url,)).fetchone():
                    return self.out(409, {"error": "This subscription is already added"})
                db_conn.execute("INSERT INTO subscriptions (id, name, url, interval_hours, created_at) VALUES (?,?,?,?,?)",
                                (sid, name or up.urlparse(url).hostname or "Subscription", url, hrs, int(time.time())))
                db_conn.commit()
            res = sync_sub(sid)
            if not res.get("ok"):
                with lock:
                    db_conn.execute("DELETE FROM subscriptions WHERE id=?", (sid,)); db_conn.commit()
                return self.out(502, {"error": "Could not fetch subscription: " + res.get("error", "unknown")})
            return self.out(200, {"id": sid, **res})

        if ep == "subscriptions/sync":
            res = sync_sub(str(b.get("id", "")))
            return self.out(200 if res.get("ok") else 502, res)

        if ep == "subscriptions/update":
            sid = str(b.get("id", ""))
            with lock:
                if not db_conn.execute("SELECT 1 FROM subscriptions WHERE id=?", (sid,)).fetchone():
                    return self.out(404, {"error": "not found"})
                if "interval_hours" in b:
                    if int(b["interval_hours"]) not in (1, 6, 12, 24):
                        return self.out(400, {"error": "Interval must be 1, 6, 12 or 24 hours"})
                    db_conn.execute("UPDATE subscriptions SET interval_hours=? WHERE id=?", (int(b["interval_hours"]), sid))
                if "enabled" in b:
                    db_conn.execute("UPDATE subscriptions SET enabled=? WHERE id=?", (1 if b["enabled"] else 0, sid))
                if str(b.get("name", "")).strip():
                    db_conn.execute("UPDATE subscriptions SET name=? WHERE id=?", (str(b["name"]).strip()[:60], sid))
                db_conn.commit()
            return self.out(200, {"ok": True})

        if ep == "subscriptions/delete":
            sid = str(b.get("id", ""))
            with lock:
                if b.get("delete_configs"):
                    for r in db_conn.execute("SELECT id FROM configs WHERE sub_id=?", (sid,)).fetchall():
                        for t, col in (("configs", "id"), ("checks", "config_id"), ("incidents", "config_id")):
                            db_conn.execute(f"DELETE FROM {t} WHERE {col}=?", (r["id"],))
                else:
                    db_conn.execute("UPDATE configs SET sub_id=NULL WHERE sub_id=?", (sid,))
                db_conn.execute("DELETE FROM subscriptions WHERE id=?", (sid,))
                db_conn.commit()
            restart_xray()
            return self.out(200, {"ok": True})

        if ep == "sparks":
            since = int(time.time()) - 3600
            with lock:
                rows = db_conn.execute("SELECT config_id, ok, latency_ms FROM checks WHERE checked_at>=? ORDER BY checked_at ASC", (since,)).fetchall()
            sp = {}
            for r in rows:
                sp.setdefault(r["config_id"], []).append(r["latency_ms"] if r["ok"] else None)
            return self.out(200, {k: v[-40:] for k, v in sp.items()})

        # History Chart Data
        if ep == "history":
            range_key = qs.get("range", ["24h"])[0]
            seconds_map = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}
            span = seconds_map.get(range_key, 86400)
            since = int(time.time()) - span
            cfg_id = qs.get("id", [None])[0]

            with lock:
                if cfg_id:
                    cur = db_conn.execute(
                        "SELECT checked_at, ok, latency_ms FROM checks WHERE config_id=? AND checked_at >= ? ORDER BY checked_at ASC",
                        (cfg_id, since)
                    )
                else:
                    cur = db_conn.execute(
                        "SELECT checked_at, ok, latency_ms FROM checks WHERE checked_at >= ? ORDER BY checked_at ASC",
                        (since,)
                    )
                rows = [dict(r) for r in cur.fetchall()]
            return self.out(200, {"points": rows, "span": span})

        # Incidents List
        if ep == "incidents":
            with lock:
                cur = db_conn.execute("""
                    SELECT i.id, i.config_id, i.started_at, i.resolved_at, i.last_error, c.name, c.addr
                    FROM incidents i
                    JOIN configs c ON c.id = i.config_id
                    ORDER BY i.started_at DESC LIMIT 100
                """)
                return self.out(200, {"incidents": [dict(r) for r in cur.fetchall()]})

        # Settings
        if ep == "settings":
            with lock:
                for k, v in b.items():
                    if k in DEF_SETTINGS and v is not None:
                        # Validation
                        if k in ("interval", "threshold", "timeout"):
                            v = str(max(1, int(v)))
                        if k == "token" and v:
                            if not re.fullmatch(r"\d+:[A-Za-z0-9_-]+", str(v)):
                                return self.out(400, {"error": "Invalid Telegram bot token format"})
                        if k == "chat" and v:
                            if not re.fullmatch(r"-?\d+|@\w+", str(v)):
                                return self.out(400, {"error": "Invalid chat ID format"})
                        db_conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))
                db_conn.commit()
            wake.set()
            return self.out(200, {"ok": True})

        # Action: Check Now
        if ep == "check-now":
            wake.set()
            return self.out(200, {"ok": True})

        # Action: Test Telegram
        if ep == "test-telegram":
            ok, used, attempts = send_telegram(
                "🛡️ <b>پیام تست سیستم پایشگر Sentinel</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                "✅ ارتباط سرور و ربات تلگرام با موفقیت برقرار شد!\n"
                "⚡ پیام از طریق مسیریابی هوشمند ارسال گردید.\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                "<i>از دکمه‌های شیشه‌ای زیر برای تعامل با ربات استفاده کنید:</i>",
                reply_markup=MAIN_KEYBOARD,
                record_trace=True
            )
            return self.out(200, {
                "ok": ok,
                "used_node": used["name"] if used else None,
                "used_addr": used["addr"] if used else None,
                "attempts": attempts
            })

        return self.out(404)

def setup_ssl(srv, port, path):
    cert_file = os.getenv("SENTINEL_SSL_CERT", D + "/certs/cert.pem")
    key_file = os.getenv("SENTINEL_SSL_KEY", D + "/certs/key.pem")
    use_https = os.getenv("SENTINEL_USE_HTTPS", "").lower() in ("1", "true", "yes") or get_settings().get("use_https") == "1"

    if use_https:
        if not (os.path.exists(cert_file) and os.path.exists(key_file)):
            os.makedirs(os.path.dirname(cert_file), exist_ok=True)
            subprocess.run([
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "3650",
                "-keyout", key_file, "-out", cert_file,
                "-subj", "/CN=sentinel"
            ], check=True, capture_output=True)
            os.chmod(key_file, 0o600)
            os.chmod(cert_file, 0o644)

        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        return "https"
    return "http"

def selftest():
    init_db()
    assert get_meta("path") is not None

    # 1. VLESS test
    test_vless = "vless://11111111-1111-1111-1111-111111111111@127.0.0.1:443?type=ws&security=tls&sni=example.com&path=%2Fws#🇩🇪 My VLESS"
    u, q, name = parse_vless(test_vless)
    assert name == "🇩🇪 My VLESS"
    c1 = {"id": "test1", "name": name, "uri": test_vless, "addr": "127.0.0.1:443", "port": 41001}
    out1 = outbound_for(c1)
    assert out1["protocol"] == "vless"

    # 2. Trojan test
    test_trojan = "trojan://password123@tr.example.com:443?security=tls&sni=tr.example.com#🇫🇮 My Trojan"
    c2 = {"id": "test2", "name": "My Trojan", "uri": test_trojan, "addr": "tr.example.com:443", "port": 41002}
    out2 = outbound_for(c2)
    assert out2["protocol"] == "trojan"
    assert out2["settings"]["servers"][0]["password"] == "password123"

    # 3. Shadowsocks test
    test_ss = "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@ss.example.com:8388#Shadowsocks-Node"
    c3 = {"id": "test3", "name": "Shadowsocks-Node", "uri": test_ss, "addr": "ss.example.com:8388", "port": 41003}
    out3 = outbound_for(c3)
    assert out3["protocol"] == "shadowsocks"

    # 4. VMess test
    vm_json = json.dumps({"add": "vm.example.com", "port": 443, "id": "11111111-1111-1111-1111-111111111111", "net": "ws", "tls": "tls", "ps": "VMess-Node"})
    test_vmess = "vmess://" + base64.b64encode(vm_json.encode()).decode()
    c4 = {"id": "test4", "name": "VMess-Node", "uri": test_vmess, "addr": "vm.example.com:443", "port": 41004}
    out4 = outbound_for(c4)
    assert out4["protocol"] == "vmess"

    # 5. Full Xray config test
    cfg = gen_xray_config([c1, c2, c3, c4])
    assert len(cfg["inbounds"]) == 4
    assert len(cfg["outbounds"]) == 4

    # 6. Flag and CC tests
    assert flag_to_cc("🇩🇪 Germany") == "DE"
    assert country_flag("DE") == "🇩🇪"
    assert country_flag("FI") == "🇫🇮"

    # 7. Sub decode test (all 4 protocols included)
    plain = f"{test_vless}\n{test_trojan}\n{test_ss}\n{test_vmess}\n"
    decoded = decode_sub(plain)
    assert len(decoded) == 4
    assert test_vmess in decoded

    for bad in ("hello world", "bm90X2FfcHJveHk="):
        try: decode_sub(bad); assert False
        except ValueError: pass
    print("Sentinel backend selftest PASSED (Multi-Protocol, GeoIP, SLA, Sub Filters).")

if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
        sys.exit(0)
    init_db()
    restart_xray()
    threading.Thread(target=worker_loop, daemon=True).start()
    threading.Thread(target=telegram_bot_worker, daemon=True).start()
    port = int(get_meta("port"))
    srv = ThreadingHTTPServer(("0.0.0.0", port), SentinelHandler)
    proto = setup_ssl(srv, port, get_meta("path"))
    print(f"Sentinel running on {proto}://0.0.0.0:{port}/{get_meta('path')}/", flush=True)
    srv.serve_forever()
